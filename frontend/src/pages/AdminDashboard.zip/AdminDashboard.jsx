// src/pages/AdminDashboard.js
import React, { useState, useEffect } from 'react';
import jwt_decode from 'jwt-decode';
import {
  FaHome, FaUsers, FaChalkboardTeacher,
  FaClipboardCheck, FaGraduationCap, FaBook, FaCog,
  FaSignOutAlt, FaCreditCard
} from "react-icons/fa";
import { useNavigate } from 'react-router-dom';

import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';

// Import the new Fee Management components
import FeeStructureManagement from '../components/admin/FeeStructureManagement'; // For Fee Structures
import StudentFeeManagement from '../components/staff/StudentFeeManagement'; // Use the staff component for Student Fees
// import RazorpayConfigManagement from '../components/admin/RazorpayConfigManagement'; // Import Razorpay config component

// Import other component pages
import AdminData from '../components/subadmin/AdminData';
import TeacherData from '../components/teachers/TeacherData';
import StudentManagement from '../components/teachers/studentmanagement/StudentManagement';
import UpdateStudent from '../components/teachers/studentmanagement/UpdateStudent';
// import AllStudent from '../components/teachers/studentmanagement/AllStudent';
// import ParentsManagement from '../components/staff/ParentsManagement';
import AttendanceManagement from '../components/teachers/AttendanceManagement';
import TeacherManagement from '../components/staff/TeacherManagement';
import ClassManagement from '../components/admin/ClassManagement';
// import CourseManagement from '../components/staff/CourseManagement';
import CertificateManagement from '../components/staff/CertificateManagement';
import OnlineExamReport from '../components/teachers/OnlineExamReport';
import EditAccount from '../components/teachers/EditAccount';
import ViewAccount from '../components/teachers/ViewAccount';
import StaffManagement from '../components/subadmin/StaffManagement';
import SubAdminManagement from '../components/admin/SubAdminManagement';
// import WebsiteManagement from '../components/subadmin/WebsiteManagement';
// import { updateStudent } from '../../../backend/controllers/studentController';

const menuItems = [
  { icon: <FaHome />, label: "Admin" },
  { icon: <FaUsers />, label: "Staff Management" },
  { icon: <FaUsers />, label: "Manage Sub Admin" },
  { icon: <FaChalkboardTeacher />, label: "Teacher Management" },
  { icon: <FaUsers />, label: "Student Management", subItems: ["Add Student", "Update Student", "All Student"] },
  // { icon: <FaUsers />, label: "Parent's Management" },
  // { icon: <FaBook />, label: "Course Management" },
  { icon: <FaBook />, label: "Class Management" },
  {
    icon: <FaClipboardCheck />,
    label: "Fee Management",
    subItems: [
      "Fee Structure Management", // Added Fee Structure Management
      "Student Fee Management", // Added Student Fee Management 
    ]
  },
  // { icon: <FaCreditCard />, label: "Payment Settings", subItems: ["Razorpay Configuration"] }, // New Payment Settings menu
  { icon: <FaClipboardCheck />, label: "Attendance Management" },
  { icon: <FaGraduationCap />, label: "Certificate Management" },
  { icon: <FaGraduationCap />, label: "Online Exam & Report Management" },
  { icon: <FaCog />, label: "Edit Account" },
  { icon: <FaCog />, label: "View Account" },
  // { icon: <FaCog />, label: "Website Management" },
  { icon: <FaSignOutAlt />, label: "Logout" }
];

const componentMap = {
  "Admin": AdminData,
  "Teacher": TeacherData,
  // Mapped new fee components
  "Fee Structure Management": FeeStructureManagement,
  "Student Fee Management": StudentFeeManagement, // Map to the staff component
  // "Razorpay Configuration": RazorpayConfigManagement, // New mapping for Razorpay config

  "Manage Sub Admin": SubAdminManagement,
  "Staff Management": StaffManagement,
  "Add Student": StudentManagement,
  "Update Student": UpdateStudent,
  // "All Student": AllStudent,
  "Teacher Management": TeacherManagement,
  // "Parent's Management": ParentsManagement,
  "Class Management": ClassManagement,
  "Attendance Management": AttendanceManagement,
  // "Course Management": CourseManagement,
  "Online Exam & Report Management": OnlineExamReport,
  "Edit Account": EditAccount,
  "View Account": ViewAccount,
  "Certificate Management": CertificateManagement,
  // "Website Management": WebsiteManagement
};

const AdminDashboard = () => {

  // ... existing state ...
  const [schoolLogo, setSchoolLogo] = useState(null); // Add schoolLogo state
  const [isSidebarExpanded, setSidebarExpanded] = useState(true);
  const [activeComponent, setActiveComponent] = useState("Admin");
  const navigate = useNavigate();

  const [userInfo, setUserInfo] = useState({
    name: "",
    role: "",
    schoolName: "",
    schoolId: ""
  });

  useEffect(() => {
    
    const name = localStorage.getItem("adminName");
    const role = localStorage.getItem("role");
    const schoolName = localStorage.getItem("schoolName");
    const schoolId = localStorage.getItem("schoolId");
    const token = localStorage.getItem("token");

    // Check if user is authenticated
    if (!token) {
      handleLogout();
      return;
    }

    let decodedSchoolName = "";
    if (token) {
      try {
        const decoded = jwt_decode(token);
        decodedSchoolName = decoded.schoolName || schoolName;

        // Check if token is expired
        if (decoded.exp && decoded.exp < Date.now() / 1000) {
          handleLogout();
          return;
        }
      } catch (err) {
        console.error("Failed to decode token", err);
        handleLogout();
        return;
      }
    }

    setUserInfo({
      name: name || "Unknown",
      role: role || "Unknown",
      schoolName: decodedSchoolName || schoolName || "Unknown School",
      schoolId: schoolId || ""
    });
  }, []);

  const handleMenuClick = (label) => {
    // console.log("Clicked menu item:", label);
    if (label === "Logout") {
      handleLogout();
    } else {
      setActiveComponent(label);
    }
  };

  const handleLogout = () => {
    // Clear all user-related data from localStorage
    localStorage.removeItem("token");
    localStorage.removeItem("adminName");
    localStorage.removeItem("role");
    localStorage.removeItem("schoolName");
    localStorage.removeItem("schoolId");

    // Redirect to login page
    navigate("/login");
  };

  const ActiveComponent = componentMap[activeComponent];

  return (
    <div className="flex">
      <Sidebar
        menuItems={menuItems}
        onMenuClick={handleMenuClick}
        isExpanded={isSidebarExpanded}
      />
      <div className="flex-1 flex flex-col">
        <Navbar
          toggleSidebar={() => setSidebarExpanded(!isSidebarExpanded)}
          name={userInfo.name}
          role={userInfo.role}
          schoolName={userInfo.schoolName}
          showSidebarToggle={true}
          onLogout={handleLogout} // Pass logout handler to Navbar
        />
        <div className="p-6">
          {/* Pass schoolId and token to the active component */}
          {ActiveComponent ? (
            <ActiveComponent schoolId={userInfo.schoolId} token={localStorage.getItem("token")} />
          ) : (
            <AdminData schoolId={userInfo.schoolId} token={localStorage.getItem("token")} />
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
