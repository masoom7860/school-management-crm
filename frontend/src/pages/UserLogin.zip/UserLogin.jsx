import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";

function UserLogin() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    role: "student",
    schoolId: ""
  });

  const [forgotPasswordMode, setForgotPasswordMode] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // State for forgot password flow data
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState("");
  const [forgotPasswordSchoolId, setForgotPasswordSchoolId] = useState("");
  const [forgotPasswordRole, setForgotPasswordRole] = useState("");


  const [error, setError] = useState("");
  const [message, setMessage] = useState(""); // For success messages
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    console.log("Attempting login with formData:", formData); // Added log

    try {
      const res = await axios.post(`${BASE_URL}/userlogin/user`, formData);
      console.log("Login successful:", res.data); // Added log
      const { token, role, schoolId, name, schoolName, userId } = res.data; // Destructure schoolName and userId from response

      localStorage.setItem("token", token);
      localStorage.setItem("role", role);
      localStorage.setItem("schoolId", schoolId);
      localStorage.setItem("schoolName", schoolName); // Store schoolName for all roles

      // Store name based on role
      if (role === "subadmin") {
        localStorage.setItem("adminName", name); // Store as adminName for subadmin
      } else {
        localStorage.setItem("userName", name); // Store as userName for other roles
      }

      // Store userId based on role
      switch (role) {
        case "student":
          localStorage.setItem("studentId", userId);
          navigate("/studentdashboard");
          break;
        case "teacher":
          localStorage.setItem("teacherId", userId);
          navigate("/teacherdashboard");
          break;
        case "staff":
          localStorage.setItem("staffId", userId);
          navigate("/staffdashboard");
          break;
        case "parent":
          localStorage.setItem("parentId", userId);
          navigate("/parentdashboard");
          break;
        case "subadmin":
          localStorage.setItem("subadminId", userId); // Store subadminId
          navigate("/admindashboard");
          break;
        default:
          navigate("/");
      }
    } catch (err) {
      console.error("Login error:", err); // Added log
      setError(err.response?.data?.error || "Login failed");
    }
  };

  const handleForgotPasswordClick = () => {
    // Check if email and school ID are entered before proceeding
    if (!formData.email || !formData.schoolId) {
      setError("Please enter your email and school ID in the login form first.");
      return;
    }

    setForgotPasswordMode(true);
    setError("");
    setMessage("");
    setOtpSent(false);
    setOtp("");
    setNewPassword("");
    setConfirmPassword("");
    // Store current login form data for forgot password flow
    setForgotPasswordEmail(formData.email);
    setForgotPasswordSchoolId(formData.schoolId);
    setForgotPasswordRole(formData.role);
  };

  const handleSendOtp = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    // Use stored forgot password data
    if (!forgotPasswordEmail || !forgotPasswordSchoolId) {
      setError("Please enter your email and school ID.");
      return;
    }

    try {
      const res = await axios.post(`${BASE_URL}/otp/send-otp`, {
        email: forgotPasswordEmail, // Use stored email
        purpose: 'forgot-password'
      });
      setMessage(res.data.message || "OTP sent successfully.");
      setOtpSent(true);
    } catch (err) {
      setError(err.response?.data?.error || "Failed to send OTP.");
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    if (!otp || !newPassword || !confirmPassword) {
      setError("Please fill in all fields.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (newPassword.length < 6) { // Basic password length validation
      setError("Password must be at least 6 characters long.");
      return;
    }


    try {
      const res = await axios.post(`${BASE_URL}/userlogin/reset-password`, {
        email: forgotPasswordEmail, // Use stored email
        schoolId: forgotPasswordSchoolId, // Use stored school ID
        role: forgotPasswordRole, // Use stored role
        otp: otp,
        newPassword: newPassword
      });
      setMessage(res.data.message || "Password reset successfully. You can now log in.");
      setForgotPasswordMode(false); // Go back to login form
      setOtpSent(false);
      setOtp("");
      setNewPassword("");
      setConfirmPassword("");
      setFormData(prev => ({ ...prev, password: "" })); // Clear password field
    } catch (err) {
      console.error('Reset password error:', err); // Log error on frontend
      const errorMessage = err.response?.data?.error || "Failed to reset password.";
      if (errorMessage.toLowerCase().includes('invalid otp') || errorMessage.toLowerCase().includes('otp expired')) {
        setError("Invalid or expired OTP. Please request a new one.");
      } else if (errorMessage.toLowerCase().includes('user not found')) {
        setError("User not found in this school. Please check email, school ID, and role.");
      }
      else {
        setError(errorMessage);
      }
    }
  };


  return (
    <div className="min-h-screen flex justify-center items-center bg-gradient-to-br from-red-100 to-purple-100">
      <form
        onSubmit={
          forgotPasswordMode
            ? otpSent
              ? handleResetPassword
              : handleSendOtp
            : handleLogin
        }
        className="bg-white p-8 rounded-lg shadow-xl w-full max-w-sm"
      >
        <h2 className="text-2xl font-bold text-center text-gray-700">
          {forgotPasswordMode
            ? otpSent
              ? "Reset Password"
              : "Forgot Password"
            : "User Login"}
        </h2>

        {error && <p className="text-red-600 text-sm text-center">{error}</p>}
        {message && (
          <p className="text-green-600 text-sm text-center">{message}</p>
        )}

        {/* Input Fields with consistent height, spacing, and width */}
        <div className="space-y-3">
          {!forgotPasswordMode && (
            <>
              <input
                type="text"
                name="schoolId"
                placeholder="School ID"
                required
                value={formData.schoolId}
                onChange={handleChange}
                className="w-full h-10 border border-gray-300 px-4 rounded-md text-sm"
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                required
                value={formData.email}
                onChange={handleChange}
                className="w-full h-10 border border-gray-300 px-4 rounded-md text-sm " />
              <input
                type="password"
                name="password"
                placeholder="Password"
                required
                value={formData.password}
                onChange={handleChange}
                className="w-full h-10 border border-gray-300 px-4 rounded-md text-sm " />
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full h-10 border border-gray-300 px-4 rounded-md text-sm "              >
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="staff">Staff</option>
                <option value="parent">Parent</option>
                <option value="subadmin">Sub Admin</option>
              </select>

              <button
                type="submit"
                className="w-full h-10 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 transition">
                Login
              </button>

              <button
                type="button"
                onClick={handleForgotPasswordClick}
                className="w-full text-red-600 text-xs text-center hover:underline">
                Forgot Password?
              </button>
            </>
          )}

          {forgotPasswordMode && !otpSent && (
            <div className="space-y-3">
              <input
                type="text"
                name="schoolId"
                placeholder="School ID"
                required
                value={formData.schoolId}
                onChange={handleChange}
                className="w-full h-12 border border-gray-300 px-4 rounded-md text-sm"
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                required
                value={formData.email}
                onChange={handleChange}
                className="w-full h-12 border border-gray-300 px-4 rounded-md text-sm"
              />
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full h-12 border border-gray-300 px-4 rounded-md text-sm"
              >
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="staff">Staff</option>
                <option value="parent">Parent</option>
                <option value="subadmin">Sub Admin</option>
              </select>
              <button
                type="submit"
                className="w-full h-12 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 transition"
              >
                Send OTP
              </button>
              <button
                type="button"
                onClick={() => setForgotPasswordMode(false)}
                className="w-full text-red-600 text-sm text-center hover:underline"
              >
                Back to Login
              </button>
            </div>
          )}

          {forgotPasswordMode && otpSent && (
            <div className="space-y-3">
              <input
                type="text"
                name="otp"
                placeholder="Enter OTP"
                required
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full h-12 border border-gray-300 px-4 rounded-md text-sm"
              />
              <input
                type="password"
                name="newPassword"
                placeholder="New Password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full h-12 border border-gray-300 px-4 rounded-md text-sm"
              />
              <input
                type="password"
                name="confirmPassword"
                placeholder="Confirm New Password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full h-12 border border-gray-300 px-4 rounded-md text-sm"
              />
              <button
                type="submit"
                className="w-full h-12 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 transition"
              >
                Reset Password
              </button>
              <button
                type="button"
                onClick={() => {
                  setOtpSent(false);
                  setOtp("");
                  setNewPassword("");
                  setConfirmPassword("");
                  setError("");
                  setMessage("");
                }}
                className="w-full text-red-600 text-sm text-center hover:underline"
              >
                Resend OTP
              </button>
              <button
                type="button"
                onClick={() => setForgotPasswordMode(false)}
                className="w-full text-red-600 text-sm text-center hover:underline"
              >
                Back to Login
              </button>
            </div>
          )}
        </div>
      </form>
    </div>
  );

}

export default UserLogin;
