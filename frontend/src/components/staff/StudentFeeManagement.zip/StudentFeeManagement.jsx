import React, { useState, useEffect } from 'react';
import { Table, Form, Input, Button, Select, Modal, message, Card, Divider, DatePicker, Tag, Spin, Typography } from 'antd';
import 'antd/dist/reset.css';
import { PlusOutlined, SearchOutlined, PrinterOutlined, DownloadOutlined, NotificationOutlined, FilePdfOutlined } from '@ant-design/icons';
import moment from 'moment';
import jwt_decode from 'jwt-decode'; // Use dash instead of underscore
import ReceiptViewerModal from './ReceiptViewerModal'; // Assuming this component exists
import { getSessions } from '../../api/sessionsApi'; // Import getSessions
import { getClasses, getSectionsByClass } from '../../api/classesApi'; // Import getClasses and getSectionsByClass from classesApi
import { getFeeStructures } from '../../api/feeStructureApi'; // Import getFeeStructures
import { getStudentsBySchoolId, getStudentsByQuery, getStudentsByClass } from '../../api/studentApi';
import { getStudentFees as fetchStudentFeesApi, getAllStudentFees as fetchAllFeesApi, addStudentPayment, generateReceiptPdf, sendDueFeeNotifications, generateMonthlyCollectionPdf, generateClassWiseRevenuePdf, generatePendingVsCollectedPdf } from '../../api/studentFeeApi'; // Import student fee APIs

const { Column } = Table;
const { Title, Text } = Typography;
const { Option } = Select; // Re-add Option for payment mode select

const StudentFeeComponent = () => {
  const [form] = Form.useForm(); // Form for Assign Fee Modal
  const [paymentForm] = Form.useForm(); // Form for Add Payment Modal
  const [students, setStudents] = useState([]); // All students for search functionality
  const [filteredStudents, setFilteredStudents] = useState([]); // Students filtered by class/section for assign fee modal
  const [feeStructures, setFeeStructures] = useState([]);
  const [classes, setClasses] = useState([]);
  const [sections, setSections] = useState([]); // State for sections
  const [studentFees, setStudentFees] = useState([]);
  const [academicYears, setAcademicYears] = useState([]); // State for academic years
  const [selectedFee, setSelectedFee] = useState(null); // Used for payment modal
  const [isAssignModalVisible, setIsAssignModalVisible] = useState(false);
  const [isPaymentModalVisible, setIsPaymentModalVisible] = useState(false);
  const [isReceiptModalVisible, setIsReceiptModalVisible] = useState(false);
  const [receiptData, setReceiptData] = useState(null);
  const [loading, setLoading] = useState({
    students: false,
    feeStructures: false,
    classes: false,
    fees: false,
    assign: false,
    payment: false,
    receipt: false,
    academicYears: false, // Loading state for academic years
  });
  const [schoolId, setSchoolId] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [searchParams, setSearchParams] = useState({
    studentId: '',
    classId: '', // Add classId to search parameters
  });
  const [staffAssignedClassId, setStaffAssignedClassId] = useState(null); // To store staff's assigned class

  // State to hold values from the assign fee form to trigger fee structure fetch
  // Initialize with academicYear so it's not null, studentId can be null initially
  const [assignFormValues, setAssignFormValues] = useState({
    academicYear: '', // Initialize as empty, will be set from fetched data
    studentId: null,
    classId: null,
    sectionId: null,
  });

  // Get auth token from localStorage and decode it
  const getAuthToken = () => {
    return localStorage.getItem('token');
  };

  // Decode token to get schoolId and user role
  const decodeToken = () => {
    const token = getAuthToken();
    if (token) {
      try {
        const decoded = jwt_decode(token);
        setSchoolId(decoded.schoolId);
        setUserRole(decoded.role);
        // Assuming staff might have a classId assigned in their token or user object
        if (decoded.role === 'staff' && decoded.classId) {
          setStaffAssignedClassId(decoded.classId);
          setSearchParams(prev => ({ ...prev, classId: decoded.classId }));
        }
        return decoded;
      } catch (error) {
        // Clear token if invalid
        localStorage.removeItem('token');
        message.error('Session expired or invalid token. Please log in again.');
        return null;
      }
    }
    return null;
  };

  // Fetch academic years from sessions API
  const fetchAcademicYears = async () => {
    setLoading(prev => ({ ...prev, academicYears: true }));
    try {
      const response = await getSessions();
      const sessionsData = Array.isArray(response) ? response : (response?.data || []);
      const years = sessionsData.map(session => ({
        value: session.yearRange,
        label: session.yearRange,
        isActive: session.isActive || false,
      })).filter(Boolean);
      setAcademicYears(years);

      // Set the default academic year to the active one, or the first one if no active
      const activeYear = years.find(year => year.isActive);
      if (activeYear) {
        setAssignFormValues(prev => ({ ...prev, academicYear: activeYear.value }));
        form.setFieldsValue({ academicYear: activeYear.value });
      } else if (years.length > 0) {
        setAssignFormValues(prev => ({ ...prev, academicYear: years[0].value }));
        form.setFieldsValue({ academicYear: years[0].value });
      }
    } catch (error) {
      message.error('Failed to fetch academic years.');
      setAcademicYears([]);
    } finally {
      setLoading(prev => ({ ...prev, academicYears: false }));
    }
  };

  // Fetch students based on schoolId
  const fetchStudents = async () => {
    const currentSchoolId = schoolId || decodeToken()?.schoolId;
    if (!currentSchoolId) {
      message.error('School ID not found in token for fetching students.');
      return;
    }

    setLoading(prev => ({ ...prev, students: true }));
    try {
      const response = await getStudentsBySchoolId(currentSchoolId);
      // Add class name to each student for display in selects/tables
      const studentsWithClassName = response.data.students.map(student => { // response.data.students as per backend response structure
        // Use classId (populated) or fallback to classAppliedFor
        const classId = student.classId?._id || student.classId;
        const studentClass = classes.find(c => c._id === classId);
        return {
          ...student,
          className: studentClass ? studentClass.className : (student.classAppliedFor || 'No Class Assigned')
        };
      });
      setStudents(studentsWithClassName);
    } catch (error) {
      message.error('Failed to fetch students.');
      setStudents([]);
    } finally {
      setLoading(prev => ({ ...prev, students: false }));
    }
  };

  // Fetch fee structures based on class ID, section ID, and academic year
  const fetchFeeStructures = async (classId, academicYear, sectionId = null) => {
    const currentSchoolId = schoolId || decodeToken()?.schoolId;
    if (!currentSchoolId) {
      message.error('School ID not found in token for fetching fee structures.');
      setFeeStructures([]);
      return;
    }

    if (!classId || !academicYear) {
      setFeeStructures([]);
      return;
    }

    setLoading(prev => ({ ...prev, feeStructures: true }));
    try {
      const filters = { classId, academicYear };
      if (sectionId) filters.sectionId = sectionId;

      const token = getAuthToken();
      const response = await getFeeStructures(currentSchoolId, filters, token);
      const fetchedFeeStructures = (response && response.data) ? response.data : [];
      setFeeStructures(fetchedFeeStructures);

      if (fetchedFeeStructures.length === 0) {
        message.warning('No fee structures available for selected criteria. Please create fee structures first using the Fee Structure Management section.');
      }
    } catch (error) {
      message.error('Failed to fetch fee structures. Check console for details.');
      setFeeStructures([]); // Ensure state is cleared on error
    } finally {
      setLoading(prev => ({ ...prev, feeStructures: false }));
    }
  };

  // Fetch classes for the current school
  const fetchClasses = async () => {
    const currentSchoolId = schoolId || decodeToken()?.schoolId;
    if (!currentSchoolId) {
      message.error('School ID not found in token for fetching classes.');
      return;
    }

    setLoading(prev => ({ ...prev, classes: true }));
    try {
      const classes = await getClasses(); // getClasses returns the data array directly
      setClasses(classes || []);
    } catch (error) {
      message.error('Failed to fetch classes.');
      setClasses([]);
    } finally {
      setLoading(prev => ({ ...prev, classes: false }));
    }
  };

  // Fetch sections for a specific class
  const fetchSections = async (classId) => {
    if (!classId) {
      setSections([]);
      return;
    }

    try {
      const sections = await getSectionsByClass(classId, schoolId || decodeToken()?.schoolId);
      setSections(sections || []); // getSectionsByClass returns the data array directly
    } catch (error) {
      message.error('Failed to fetch sections.');
      setSections([]);
    }
  };

  // Fetch filtered students based on class and section for assign fee modal
  const fetchFilteredStudents = async (classId, sectionId = null) => {
    if (!classId) {
      setFilteredStudents([]);
      return;
    }

    try {
      const params = { classId };
      if (sectionId) {
        // Find the selected section to get its name
        const selectedSection = sections.find(s => s._id === sectionId);
        if (selectedSection) {
          params.section = selectedSection.name;
        }
      }

      const response = await getStudentsByClass(classId, schoolId || decodeToken()?.schoolId);
      const filteredStudentsData = response.students || []; // getStudentsByClass returns { students: [...] }

      // Add class name to each student for display
      const studentsWithClassName = filteredStudentsData.map(student => {
        const studentClass = classes.find(c => c._id === classId);
        return {
          ...student,
          className: studentClass ? studentClass.className : 'Unknown Class'
        };
      });

      setFilteredStudents(studentsWithClassName);
    } catch (error) {
      message.error('Failed to fetch filtered students.');
      setFilteredStudents([]);
    }
  };

  // Fetch student fees. Fetches all if studentId is null or undefined.
  const fetchStudentFees = async (studentId = null, classId = null) => {
    const currentSchoolId = schoolId || decodeToken()?.schoolId;
    if (!currentSchoolId) {
      message.error('School ID not found in token for fetching student fees.');
      setStudentFees([]);
      return;
    }

    setLoading(prev => ({ ...prev, fees: true }));
    try {
      const token = getAuthToken();
      let response;
      const queryParams = {};
      if (classId) {
        queryParams.classId = classId;
      }

      if (studentId) {
        response = await fetchStudentFeesApi(studentId, token, currentSchoolId);
      } else {
        response = await fetchAllFeesApi(currentSchoolId, queryParams, token); // Pass queryParams
      }

      const fetchedFees = response.data || [];

      const feesWithStudentDetails = fetchedFees.map(fee => {
        return {
          ...fee,
          studentName: fee.studentId?.name || 'Unknown Student',
          studentRollNumber: fee.studentId?.rollNumber || '-',
          studentClassName: fee.classId?.className || 'Unknown Class',
        };
      });

      setStudentFees(feesWithStudentDetails);

      if (feesWithStudentDetails.length === 0) {
        message.info(studentId ? 'No fee records found for this student.' : 'No fee records found.');
      }

    } catch (error) {
      message.error(error.response?.data?.message || 'Failed to fetch student fees.');
      setStudentFees([]);
    } finally {
      setLoading(prev => ({ ...prev, fees: false }));
    }
  };

  // Handle download receipt
  const handleDownloadReceipt = async (feeId, receiptNumber) => {
    if (!feeId || !receiptNumber) {
      message.error('Fee ID or Receipt Number is missing for download.');
      return;
    }
    setLoading(prev => ({ ...prev, receipt: true }));
    try {
      const token = getAuthToken();
      const currentSchoolId = schoolId || decodeToken()?.schoolId;
      const response = await generateReceiptPdf(feeId, receiptNumber, token, currentSchoolId);

      const blob = new Blob([response], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      let filename = `receipt_${receiptNumber}.pdf`;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();

      link.remove();
      window.URL.revokeObjectURL(url);

      message.success('Receipt downloaded successfully');
    } catch (error) {
      message.error(error?.message || 'Failed to download receipt.');
    } finally {
      setLoading(prev => ({ ...prev, receipt: false }));
    }
  };

  // Handle assign fee with schoolId from token
  const handleAssignFee = async (values) => {
    const tokenData = decodeToken();
    if (!tokenData?.schoolId) {
      message.error('School ID not found in token. Cannot assign fee.');
      return;
    }

    const selectedFeeStructure = feeStructures.find(fs => fs._id === values.feeStructureId);
    if (!selectedFeeStructure) {
        message.error('Selected fee structure not found. Please select a valid fee structure.');
        return;
    }

    setLoading(prev => ({ ...prev, assign: true }));
    try {
      const payload = {
        studentId: values.studentId,
        classId: values.classId,
        feeStructureId: values.feeStructureId,
        academicYear: values.academicYear,
        schoolId: tokenData.schoolId,
        totalFee: selectedFeeStructure.totalAmount,
        dueAmount: selectedFeeStructure.totalAmount,
        createdBy: tokenData.adminId || tokenData.userId
      };

      const token = getAuthToken();
      await assignStudentFee(payload, token, tokenData.schoolId);
      message.success('Fee assigned successfully');
      setIsAssignModalVisible(false);
      form.resetFields();
      setAssignFormValues({
          academicYear: assignFormValues.academicYear, // Keep the current academic year
          studentId: null,
          classId: null,
          sectionId: null,
      });
      fetchStudentFees(values.studentId);
    } catch (error) {
      message.error(error.response?.data?.message || 'Failed to assign fee.');
    } finally {
      setLoading(prev => ({ ...prev, assign: false }));
    }
  };

  // Handle add payment
  const handleAddPayment = async (values) => {
    if (!selectedFee?._id) {
      message.error('No fee record selected for payment.');
      return;
    }

    setLoading(prev => ({ ...prev, payment: true }));
    try {
      const payload = {
        amount: parseFloat(values.amount),
        paymentMode: values.paymentMode,
        remark: values.remark,
      };

      const token = getAuthToken();
      const currentSchoolId = schoolId || decodeToken()?.schoolId;
      await addStudentPayment(selectedFee._id, payload, token, currentSchoolId);
      message.success('Payment added successfully');
      setIsPaymentModalVisible(false);
      paymentForm.resetFields();
      if (selectedFee?.studentId) {
        fetchStudentFees(selectedFee.studentId);
      } else {
        fetchStudentFees();
      }
    } catch (error) {
      message.error(error.response?.data?.message || 'Failed to add payment.');
    } finally {
      setLoading(prev => ({ ...prev, payment: false }));
    }
  };

  // Handle view receipt
  const handleViewReceipt = async (feeId, receiptNumber) => {
    setLoading(prev => ({ ...prev, receipt: true }));
    try {
      const token = getAuthToken();
      const currentSchoolId = schoolId || decodeToken()?.schoolId;
      const response = await generateReceiptPdf(feeId, receiptNumber, token, currentSchoolId);
      const blob = new Blob([response], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
      // Caller can optionally revokeObjectURL later if stored
    } catch (error) {
      message.error('Failed to open receipt.');
    } finally {
      setLoading(prev => ({ ...prev, receipt: false }));
    }
  };

  // Handle search. Fetches all fees if studentId is empty.
  const handleSearch = (values) => {
    setSearchParams(values);
    fetchStudentFees(values.studentId || null);
  };

  // Status tag color logic
  const getStatusTagColor = (status) => {
    switch (status) {
      case 'Paid': return 'green';
      case 'Pending': return 'red';
      case 'Partially Paid': return 'orange';
      default: return 'red';
    }
  };

  // Initial data fetch on component mount
  useEffect(() => {
    const tokenInfo = decodeToken();
    if (tokenInfo?.schoolId) {
      fetchAcademicYears(); // Fetch academic years first
      fetchClasses().then(() => {
        fetchStudents();
      });
      // Pass initial classId from searchParams (which might be set by staffAssignedClassId)
      fetchStudentFees(null, searchParams.classId);
    }
  }, []);

  // Re-fetch student fees when searchParams change
  useEffect(() => {
    if (schoolId) {
      fetchStudentFees(searchParams.studentId, searchParams.classId);
    }
  }, [schoolId, searchParams.studentId, searchParams.classId]);

  // Effect to fetch sections when class changes in assign form
  useEffect(() => {
    if (!isAssignModalVisible) {
      setSections([]);
      return;
    }

    const { classId } = assignFormValues;
    if (classId) {
      fetchSections(classId);
    } else {
      setSections([]);
    }
  }, [assignFormValues.classId, isAssignModalVisible]);

  // Effect to fetch filtered students when class or section changes in assign form
  useEffect(() => {
    if (!isAssignModalVisible) {
      setFilteredStudents([]);
      return;
    }

    const { classId, sectionId } = assignFormValues;
    if (classId) {
      fetchFilteredStudents(classId, sectionId);
    } else {
      setFilteredStudents([]);
    }
  }, [assignFormValues.classId, assignFormValues.sectionId, isAssignModalVisible, sections]);

  // Effect to fetch fee structures when class, section, or academic year changes in assign form
  useEffect(() => {
    if (!isAssignModalVisible) {
      setFeeStructures([]);
      return;
    }

    const { classId, academicYear, sectionId } = assignFormValues;

    if (classId && academicYear) {
      fetchFeeStructures(classId, academicYear, sectionId);
    } else {
      setFeeStructures([]);
    }
  }, [assignFormValues.classId, assignFormValues.academicYear, assignFormValues.sectionId, isAssignModalVisible]);

  // Effect to log the state of feeStructures and loading after fetch attempts
  useEffect(() => {
  }, [feeStructures, loading.feeStructures]);


  // Re-fetch students after classes are updated, to ensure className is correctly mapped
  useEffect(() => {
    if (classes.length > 0) {
      fetchStudents();
    }
  }, [classes]);

  // Display a loading spinner for initial data fetches
  if (loading.students || loading.classes || loading.academicYears) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <Card
        title={<Title level={3} className="text-center">Student Fee Management</Title>}
        variant="borderless"
        extra={
          <Text strong>School: {localStorage.getItem('schoolName') || 'My School'}</Text>
        }
        className="shadow-lg rounded-lg"
      >
        {/* Search Section */}
        <Form layout="inline" onFinish={handleSearch} initialValues={searchParams} className="flex flex-wrap items-center gap-4 mb-4">
          <Form.Item name="classId" label="Class" className="flex-grow">
            <Select
              showSearch
              placeholder="Select class"
              style={{ minWidth: 200 }}
              optionFilterProp="label"
              filterOption={(input, option) =>
                option.label.toLowerCase().includes(input.toLowerCase())
              }
              loading={loading.classes}
              options={classes.map(cls => ({
                value: cls._id,
                label: cls.className,
              }))}
              allowClear
              disabled={userRole === 'staff' && staffAssignedClassId} // Disable if staff has assigned class
            />
          </Form.Item>
          <Form.Item name="studentId" label="Student" className="flex-grow">
            <Select
              showSearch
              placeholder="Select student"
              style={{ minWidth: 200 }}
              optionFilterProp="label"
              filterOption={(input, option) =>
                option.label.toLowerCase().includes(input.toLowerCase())
              }
              loading={loading.students}
              options={students
                .filter(student => !searchParams.classId || student.classId === searchParams.classId)
                .map(student => ({
                  value: student._id,
                  label: `${student.name} (${student.rollNumber}) - ${student.className}`,
                }))}
              allowClear
            />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" icon={<SearchOutlined />} loading={loading.fees}>
              Search
            </Button>
          </Form.Item>
        </Form>

        <Divider />

        {/* Action Buttons */}
        <div className="mb-4 flex gap-2 flex-wrap">
          {/* Assign Fee button is removed for staff */}
          {/*
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => {
                setIsAssignModalVisible(true);
                form.resetFields();
                // Set academic year from state, which is populated by fetchAcademicYears
                form.setFieldsValue({ academicYear: assignFormValues.academicYear });
                setAssignFormValues(prev => ({
                    ...prev,
                    studentId: null,
                    classId: null,
                    sectionId: null,
                }));
            }}
            disabled={userRole === 'staff'}
          >
            Assign Fee
          </Button>
          */}

          <Button
            icon={<NotificationOutlined />}
            onClick={async () => {
              try {
                const token = getAuthToken();
                const currentSchoolId = schoolId || decodeToken()?.schoolId;
                if (!currentSchoolId) return message.error('School ID missing');
                await sendDueFeeNotifications(currentSchoolId, { notificationType: 'email', academicYear: assignFormValues.academicYear }, token);
                message.success('Due fee notifications triggered');
              } catch (err) {
                message.error(err?.message || 'Failed to send notifications');
              }
            }}
          >
            Send Due Notifications
          </Button>

          <Button
            icon={<FilePdfOutlined />}
            onClick={async () => {
              try {
                const token = getAuthToken();
                const currentSchoolId = schoolId || decodeToken()?.schoolId;
                if (!currentSchoolId) return message.error('School ID missing');
                const blob = await generateMonthlyCollectionPdf(currentSchoolId, { academicYear: assignFormValues.academicYear }, token);
                const url = window.URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }));
                const a = document.createElement('a');
                a.href = url; a.download = 'monthly-collection.pdf';
                document.body.appendChild(a); a.click(); a.remove();
                window.URL.revokeObjectURL(url);
              } catch (err) {
                message.error('Failed to download monthly collection PDF');
              }
            }}
          >
            Download Monthly Summary
          </Button>
        </div>

        {/* Student Fees Table */}
        <Table
          dataSource={studentFees}
          loading={loading.fees}
          rowKey="_id"
          expandable={{
            expandedRowRender: record => (
              <div className="m-0 p-4 bg-gray-50 rounded-md">
                <h4 className="text-lg font-semibold mb-2">Payment History</h4>
                <Table
                  dataSource={record.payments}
                  pagination={false}
                  rowKey="receiptNumber"
                  size="small"
                >
                  <Column title="Receipt No" dataIndex="receiptNumber" key="receiptNumber" />
                  <Column title="Amount" dataIndex="amount" key="amount" render={amount => `₹${amount}`} />
                  <Column title="Date" dataIndex="date" key="date" render={date => moment(date).format('DD/MM/YYYY')} />
                  <Column title="Mode" dataIndex="mode" key="mode" />
                  <Column
                    title="Action"
                    key="action"
                    render={(_, payment) => (
                      <Button
                        size="small"
                        icon={<PrinterOutlined />}
                        onClick={() => handleViewReceipt(record._id, payment.receiptNumber)}
                        loading={loading.receipt}
                      >
                        View Receipt
                      </Button>
                    )}
                  />
                </Table>
              </div>
            ),
            rowExpandable: record => record.payments && record.payments.length > 0
          }}
        >
          <Column
            title="Student"
            dataIndex="studentName"
            key="studentName"
            render={(text, record) => `${record.studentName} (${record.studentRollNumber})`}
          />
          <Column
            title="Class"
            dataIndex="studentClassName"
            key="studentClassName"
          />
          <Column title="Academic Year" dataIndex="academicYear" key="academicYear" />
          <Column
            title="Fee Structure"
            dataIndex="feeStructureId"
            key="feeStructureId"
            render={(feeStructureId) => {
              const feeStruct = feeStructures.find(f => f._id === feeStructureId);
              return feeStruct ? feeStruct.name : '-';
            }}
          />
          <Column title="Total Fee" dataIndex="totalFee" key="totalFee" render={amount => `₹${amount}`} />
          <Column title="Paid Amount" dataIndex="paidAmount" key="paidAmount" render={amount => `₹${amount}`} />
          <Column title="Due Amount" dataIndex="dueAmount" key="dueAmount" render={amount => `₹${amount}`} />
          <Column
            title="Status"
            dataIndex="status"
            key="status"
            render={(status) => (
              <Tag color={getStatusTagColor(status)}>
                {status.toUpperCase()}
              </Tag>
            )}
          />
          <Column
            title="Action"
            key="action"
            render={(_, record) => (
            <Button
              type="link"
              onClick={() => {
                setSelectedFee(record);
                setIsPaymentModalVisible(true);
                paymentForm.resetFields();
              }}
              disabled={record.status === 'Paid'} // Staff can add payments
            >
              Add Payment
            </Button>
            )}
          />
        </Table>
      </Card>

      {/* Assign Fee Modal */}
      <Modal
        title="Assign Fee to Student"
        open={isAssignModalVisible}
        onCancel={() => setIsAssignModalVisible(false)}
        footer={null}
        destroyOnHidden={true}
      >
        {/* Assign Fee Modal content is removed for staff */}
      </Modal>

      {/* Add Payment Modal */}
      <Modal
        title={`Add Payment for ${selectedFee ? (students.find(s => s._id === selectedFee.studentId)?.name || 'Student') : 'Selected Student'}`}
        open={isPaymentModalVisible}
        onCancel={() => setIsPaymentModalVisible(false)}
        footer={null}
        destroyOnHidden={true}
      >
        {selectedFee && (
          <div className="mb-4 p-4 bg-red-50 rounded-md">
            <p><strong>Total Fee:</strong> ₹{selectedFee.totalFee}</p>
            <p><strong>Paid Amount:</strong> ₹{selectedFee.paidAmount}</p>
            <p><strong>Due Amount:</strong> ₹{selectedFee.dueAmount}</p>
          </div>
        )}

        <Form form={paymentForm} layout="vertical" onFinish={handleAddPayment} className="space-y-4">
          <Form.Item
            name="amount"
            label="Amount"
            rules={[
              { required: true, message: 'Please enter amount' },
              {
                validator: (_, value) => {
                  const numValue = parseFloat(value);
                  if (isNaN(numValue)) {
                      return Promise.reject('Please enter a valid number');
                  }
                  if (numValue <= 0) {
                    return Promise.reject('Amount must be greater than 0');
                  }
                  if (selectedFee && numValue > selectedFee.dueAmount) {
                    return Promise.reject(`Amount cannot exceed due amount (₹${selectedFee.dueAmount})`);
                  }
                  return Promise.resolve();
                }
              }
            ]}
          >
            <Input type="number" placeholder="Enter amount" step="0.01" />
          </Form.Item>

          <Form.Item
            name="paymentMode"
            label="Payment Mode"
            rules={[{ required: true, message: 'Please select payment mode' }]}
          >
            <Select placeholder="Select payment mode">
              <Option value="Cash">Cash</Option>
              <Option value="Cheque">Cheque</Option>
              <Option value="UPI">UPI</Option>
              <Option value="Online">Online</Option>
            </Select>
          </Form.Item>

          <Form.Item name="remark" label="Remark">
            <Input.TextArea placeholder="Enter any remark (optional)" />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading.payment}>
              Record Payment
            </Button>
          </Form.Item>
        </Form>
      </Modal>

      {/* Receipt Modal */}
      <Modal
        title="Payment Receipt"
        open={isReceiptModalVisible}
        width={800}
        onCancel={() => setIsReceiptModalVisible(false)}
        footer={[
          <Button key="print" icon={<PrinterOutlined />} onClick={() => window.print()}>
            Print
          </Button>,
          <Button
            key="download"
            icon={<DownloadOutlined />}
            onClick={() => handleDownloadReceipt(receiptData?.studentFeeId, receiptData?.receiptNumber)}
            disabled={!receiptData?.studentFeeId || !receiptData?.receiptNumber || loading.receipt}
            loading={loading.receipt}
          >
            Download
          </Button>,
          <Button key="close" onClick={() => setIsReceiptModalVisible(false)}>
            Close
          </Button>
        ]}
        destroyOnHidden={true}
      >
        {receiptData ? <ReceiptViewerModal data={receiptData} /> : <Spin />}
      </Modal>
    </div>
  );
}; 

export default StudentFeeComponent;
 