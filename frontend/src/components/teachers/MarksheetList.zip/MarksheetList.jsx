import React from 'react';

const MarksheetList = ({
  items,
  loading,
  filters,
  setFilters,
  classes,
  students,
  exams,
  loadList,
  editItem,
  delItem,
  downloadPdf
}) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-300">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
        <h2 className="text-2xl font-bold text-gray-800 border-b-2 border-blue-800 pb-1">Marksheet Records</h2>
        <div className="flex flex-wrap gap-2">
          <select 
            value={filters.classId} 
            onChange={(e) => setFilters({ ...filters, classId: e.target.value })} 
            className="border border-gray-400 rounded px-3 py-2 text-sm bg-gray-50"
          >
            <option value="">All Classes</option>
            {classes.map((c) => <option key={c._id} value={c._id}>{c.className}</option>)}
          </select>
          <select 
            value={filters.studentId} 
            onChange={(e) => setFilters({ ...filters, studentId: e.target.value })} 
            className="border border-gray-400 rounded px-3 py-2 text-sm bg-gray-50"
          >
            <option value="">All Students</option>
            {students.map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}
          </select>
          <select 
            value={filters.examId} 
            onChange={(e) => setFilters({ ...filters, examId: e.target.value })} 
            className="border border-gray-400 rounded px-3 py-2 text-sm bg-gray-50"
          >
            <option value="">All Exams</option>
            {exams.map((x) => <option key={x._id} value={x._id}>{x.title}</option>)}
          </select>
          <input 
            value={filters.session} 
            onChange={(e) => setFilters({ ...filters, session: e.target.value })} 
            placeholder="Session" 
            className="border border-gray-400 rounded px-3 py-2 text-sm bg-gray-50" 
          />
          <button 
            onClick={loadList} 
            className="px-4 py-2 bg-blue-800 text-white rounded font-medium hover:bg-blue-900 transition-colors"
          >
            Apply Filters
          </button>
        </div>
      </div>

      <div className="overflow-x-auto border border-gray-400 rounded-lg">
        <table className="min-w-full text-sm marksheet-table">
          <thead>
            <tr className="bg-blue-900 text-white">
              <th className="py-3 px-4 text-left border-r border-gray-300">Student Information</th>
              <th className="py-3 px-4 text-left border-r border-gray-300">Academic Details</th>
              <th className="py-3 px-4 text-center border-r border-gray-300">Marks Summary</th>
              <th className="py-3 px-4 text-center border-r border-gray-300">Result</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td className="py-6 text-center" colSpan="5">
                  <div className="flex justify-center items-center">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-800"></div>
                    <span className="ml-2">Loading marksheets...</span>
                  </div>
                </td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td className="py-6 text-center" colSpan="5">
                  <div className="text-gray-500">
                    <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="mt-2">No marksheet records found</p>
                  </div>
                </td>
              </tr>
            ) : (
              items.map((m) => (
                <tr key={m._id} className="border-b border-gray-300 hover:bg-gray-50">
                  <td className="py-3 px-4 border-r border-gray-300">
                    <div className="font-semibold">{m.studentId?.name}</div>
                    <div className="text-xs text-gray-600 mt-1">
                      Roll No: {m.studentId?.rollNumber || 'N/A'}
                    </div>
                    <div className="text-xs text-gray-600">
                      Father: {m.studentId?.fatherName || 'Not specified'}
                    </div>
                  </td>
                  <td className="py-3 px-4 border-r border-gray-300">
                    <div>{m.classId?.className}</div>
                    <div className="text-xs text-gray-600">
                      Section: {m.sectionId?.name || m.sectionId?.sectionName || 'N/A'}
                    </div>
                    <div className="text-xs text-gray-600">
                      Exam: {m.examId?.title}
                    </div>
                    <div className="text-xs text-gray-600">
                      Session: {m.session}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center border-r border-gray-300">
                    <div className="font-medium">{m.totalObtained}/{m.totalMaxMarks}</div>
                    <div className="text-sm text-gray-700">{m.percentage}%</div>
                    <div className="text-sm text-gray-700">Grade: {m.grade}</div>
                  </td>
                  <td className="py-3 px-4 text-center border-r border-gray-300">
                    <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${m.status === 'PASS' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {m.status}
                    </div>
                    <div className="text-xs text-gray-600 mt-1">
                      {m.status === 'PASS' ? 'Promoted' : 'Not Promoted'}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex flex-col sm:flex-row gap-2 justify-center">
                      <button 
                        onClick={() => alert(JSON.stringify(m, null, 2))} 
                        className="px-3 py-1.5 bg-gray-600 text-white rounded text-xs hover:bg-gray-700 transition-colors"
                        title="View Details"
                      >
                        View
                      </button>
                      <button 
                        onClick={() => editItem(m)} 
                        className="px-3 py-1.5 bg-amber-600 text-white rounded text-xs hover:bg-amber-700 transition-colors"
                        title="Edit Marksheet"
                      >
                        Edit
                      </button>
                      <button 
                        onClick={() => delItem(m._id)} 
                        className="px-3 py-1.5 bg-red-600 text-white rounded text-xs hover:bg-red-700 transition-colors"
                        title="Delete Marksheet"
                      >
                        Delete
                      </button>
                      <button 
                        onClick={() => downloadPdf(m._id)} 
                        className="px-3 py-1.5 bg-blue-800 text-white rounded text-xs hover:bg-blue-900 transition-colors flex items-center justify-center gap-1"
                        title="Download PDF"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        PDF
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {items.length > 0 && (
        <div className="mt-4 text-xs text-gray-500 text-center">
          Note: University does not own for the errors or omissions, if any, in this statement.
          <br />
          Correction, if any to be reported within 7 days of publication of Result.
        </div>
      )}
    </div>
  );
};

export default MarksheetList;