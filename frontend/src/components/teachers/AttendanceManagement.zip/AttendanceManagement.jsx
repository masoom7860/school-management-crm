import React, { useState, useEffect } from 'react';
import axios from 'axios'; // Use axios directly for new endpoints
import jwt_decode from 'jwt-decode'; // Import jwt_decode
import {
  getAttendanceBySchool, // Keep if needed for overall view, but likely not for teacher
  updateAttendance, // Keep if needed for single record update
  deleteAttendance // Keep if needed for single record delete
} from '../teachers/AttendanceApi'; // Assuming these are wrappers around axios

const baseURL = import.meta.env.VITE_API_BASE_URL;

const TeacherAttendanceManagement = () => {
  const [teacherId, setTeacherId] = useState('');
  const [schoolId, setSchoolId] = useState(''); // Assuming schoolId is also needed for batch marking
  const [assignedStudents, setAssignedStudents] = useState([]);
  const [attendanceDate, setAttendanceDate] = useState('');
  const [attendanceStatus, setAttendanceStatus] = useState({}); // { studentId: status }
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage, ] = useState(null);

  // State for report download
  const [reportStartDate, setReportStartDate] = useState('');
  const [reportEndDate, setReportEndDate] = useState('');
  const [reportLoading, setReportLoading] = useState(false);


  useEffect(() => {
    const token = localStorage.getItem('token');

    if (!token) {
      setError("Authentication token not found. Please log in again.");
      setLoading(false);
      return;
    }

    let decodedToken;
    try {
      decodedToken = jwt_decode(token);
      console.log("Decoded Token:", decodedToken); // Log decoded token
    } catch (err) {
      console.error("Failed to decode token", err);
      setError("Invalid authentication token. Please log in again.");
      setLoading(false);
      return;
    }

    // Assuming the token payload contains userId (as teacherId) and schoolId
    // Adjust keys if necessary based on actual token structure
    const extractedTeacherId = decodedToken.id; // Extracting user ID from token payload
    const extractedSchoolId = decodedToken.schoolId;

    console.log("Extracted Teacher ID:", extractedTeacherId); // Log extracted teacher ID
    console.log("Extracted School ID:", extractedSchoolId); // Log extracted school ID


    if (extractedTeacherId !== undefined && extractedTeacherId !== null && extractedSchoolId !== undefined && extractedSchoolId !== null) {
      setTeacherId(extractedTeacherId);
      setSchoolId(extractedSchoolId);

      const fetchAssignedStudents = async () => {
        try {
          const response = await axios.get(`${baseURL}/api/students/teacher/${extractedTeacherId}/students`, {
            params: { // Add params object for query parameters
              schoolId: extractedSchoolId // Include schoolId as a query parameter
            },
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          setAssignedStudents(response.data.students);
          setLoading(false);
        } catch (err) {
          console.error("Error fetching assigned students:", err);
          setError("Failed to load assigned students.");
          setLoading(false);
        }
      };

      fetchAssignedStudents();

    } else {
      setError("Teacher ID or School ID not found in token payload. Please log in again.");
      setLoading(false);
    }

  }, []); // Empty dependency array means this runs once on mount

  // Optional: Fetch existing attendance for the selected date when date changes
  useEffect(() => {
    if (attendanceDate && assignedStudents.length > 0) {
      const fetchAttendanceForDate = async () => {
        try {
          // This requires a new backend endpoint to get attendance for a list of students on a specific date
          // For now, we'll initialize status to empty and assume marking will create/update
          // A more complete implementation would fetch existing records here.
          const initialStatus = {};
          assignedStudents.forEach(student => {
            initialStatus[student._id] = ''; // Initialize status to empty
          });
          setAttendanceStatus(initialStatus);

        } catch (err) {
           console.error("Error fetching attendance for date:", err);
           // Handle error, but don't block marking attendance
        }
      };
      fetchAttendanceForDate();
    }
  }, [attendanceDate, assignedStudents]);


  const handleStatusChange = (studentId, status) => {
    setAttendanceStatus({
      ...attendanceStatus,
      [studentId]: status,
    });
  };

  const handleMarkBatchAttendance = async () => {
    if (!attendanceDate) {
      setMessage("Please select a date to mark attendance.");
      return;
    }

    setLoading(true);
    setError(null);
    setMessage(null);

    const attendanceRecords = assignedStudents.map(student => ({
      studentId: student._id,
      schoolId: schoolId, // Use schoolId from state
      date: attendanceDate,
      status: attendanceStatus[student._id] || 'Absent', // Default to Absent if not marked
      recordedBy: teacherId, // Use the teacherId (ObjectId) from state
      note: '', // Optional note field
    }));

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(`${baseURL}/attendance/batch`, { attendanceRecords }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setMessage(response.data.message);
      setLoading(false);
      // Optionally, clear selected statuses or refetch attendance for the date
      // setAttendanceStatus({});
    } catch (err) {
      console.error("Error marking batch attendance:", err);
      setError(err.response?.data?.message || "Failed to mark attendance.");
      setLoading(false);
    }
  };

  const handleDownloadReport = async () => {
    if (!reportStartDate || !reportEndDate) {
      setMessage("Please select both start and end dates for the report.");
      return;
    }

    setReportLoading(true);
    setError(null);
    setMessage(null);

    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${baseURL}/attendance/report`, {
        params: {
          teacherId: teacherId, // Use teacherId from state
          startDate: reportStartDate,
          endDate: reportEndDate,
        },
        headers: {
          Authorization: `Bearer ${token}`,
        },
        responseType: 'blob', // Important for downloading files
      });

      // Create a blob from the response data
      const blob = new Blob([response.data], { type: 'text/csv' });

      // Create a link element and trigger the download
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `attendance_report_${teacherId}_${reportStartDate}_to_${reportEndDate}.csv`;
      link.click();

      // Clean up the blob object
      window.URL.revokeObjectURL(link.href);

      setMessage("Attendance report downloaded successfully.");
      setReportLoading(false);
    } catch (err) {
      console.error("Error downloading report:", err);
      setError(err.response?.data?.message || "Failed to download attendance report.");
      setReportLoading(false);
    }
  };


  if (loading) {
    return <div className="text-center py-8">Loading assigned students...</div>;
  }

  if (error) {
    return <div className="text-red-500 text-center py-8">{error}</div>;
  }

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-6 text-gray-800">Teacher Attendance Management</h1>

      {message && <div className="bg-green-200 text-green-800 p-3 rounded mb-4">{message}</div>}
      {error && <div className="bg-red-200 text-red-800 p-3 rounded mb-4">{error}</div>}


      {/* Mark Attendance Section */}
      <div className="bg-white shadow-md rounded-lg p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4 text-gray-800">Mark Attendance for {attendanceDate || 'a Date'}</h2>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">Select Date:</label>
          <input
            type="date"
            className="p-2 border border-gray-300 rounded-md"
            value={attendanceDate}
            onChange={(e) => setAttendanceDate(e.target.value)}
          />
        </div>

        {attendanceDate && assignedStudents.length > 0 && (
          <>
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {assignedStudents.map(student => (
                  <tr key={student._id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{student.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <select
                        className="p-2 border border-gray-300 rounded-md"
                        value={attendanceStatus[student._id] || ''}
                        onChange={(e) => handleStatusChange(student._id, e.target.value)}
                      >
                        <option value="">Select Status</option>
                        <option value="Present">Present</option>
                        <option value="Absent">Absent</option>
                        <option value="Late">Late</option>
                        <option value="Excused">Excused</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button
              onClick={handleMarkBatchAttendance}
              className="mt-6 bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={loading}
            >
              {loading ? 'Saving...' : 'Save Attendance'}
            </button>
          </>
        )}
         {attendanceDate && assignedStudents.length === 0 && (
             <p className="text-gray-600">No students assigned to you.</p>
         )}
      </div>

      {/* Download Report Section */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-800">Download Attendance Report</h2>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Start Date:</label>
            <input
              type="date"
              className="p-2 border border-gray-300 rounded-md w-full"
              value={reportStartDate}
              onChange={(e) => setReportStartDate(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">End Date:</label>
            <input
              type="date"
              className="p-2 border border-gray-300 rounded-md w-full"
              value={reportEndDate}
              onChange={(e) => setReportEndDate(e.target.value)}
            />
          </div>
        </div>
        <button
          onClick={handleDownloadReport}
          className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={reportLoading}
        >
          {reportLoading ? 'Generating...' : 'Download Report'}
        </button>
      </div>

    </div>
  );
};

export default TeacherAttendanceManagement;
