import { useEffect, useMemo, useState } from 'react'; // React hooks for side effects, memoization, and state management
import api from '../../api/marksheetsApi'; // API service for marksheet operations
import { toast } from 'react-hot-toast'; // For displaying notifications
import MarksheetList from './MarksheetList'; // We'll create this component

// Default structure for a subject in the marksheet
const defaultSubject = { subjectId: '', subjectName: '', maxMarks: 100, passingMarks: 33, marksObtained: 0 };

// Computes total marks obtained, total maximum marks, and percentage from a list of subjects
const computeTotals = (subjects) => {
  const totalObtained = subjects.reduce((s, x) => s + Number(x.marksObtained || 0), 0); // Sum of marks obtained
  const totalMaxMarks = subjects.reduce((s, x) => s + Number(x.maxMarks || 0), 0); // Sum of maximum marks
  const percentage = totalMaxMarks > 0 ? Math.round((totalObtained / totalMaxMarks) * 10000) / 100 : 0; // Calculate percentage
  return { totalObtained, totalMaxMarks, percentage };
};

// Determines the grade based on the given percentage
const gradeFromPercentage = (p) => {
  if (p >= 90) return 'A+';
  if (p >= 80) return 'A';
  if (p >= 70) return 'B+';
  if (p >= 60) return 'B';
  if (p >= 50) return 'C+';
  if (p >= 40) return 'C';
  if (p >= 33) return 'D';
  return 'F';
};

// Determines the pass/fail status based on the given percentage
const statusFromPercentage = (p) => (p >= 33 ? 'PASS' : 'FAIL');

// Placeholder for authentication headers, currently not used but kept for potential future compatibility
const authHeaders = () => ({ });

// Validates the marksheet form data before submission
const validateForm = (form, students) => {
  // Check if all required fields are filled
  if (!form.session || !form.classId || !form.sectionId || !form.examId || !form.studentId) {
    return 'All fields (session, class, section, exam, student) are required.';
  }
  // Validate if the selected student exists in the current student list
  if (!students.some(s => s._id === form.studentId)) {
    return 'Selected student is not valid.';
  }
  // Ensure at least one subject is added
  if (!Array.isArray(form.subjects) || form.subjects.length === 0) {
    return 'At least one subject is required.';
  }
  // Validate each subject's fields
  for (const [i, sub] of form.subjects.entries()) {
    if (!sub.subjectId) return `Subject is required for subject #${i + 1}`;
    if (sub.maxMarks == null || sub.maxMarks === '') return `Max marks required for subject #${i + 1}`;
    if (sub.passingMarks == null || sub.passingMarks === '') return `Passing marks required for subject #${i + 1}`;
    if (sub.marksObtained == null || sub.marksObtained === '') return `Marks obtained required for subject #${i + 1}`;
  }
  return null; // Return null if validation passes
};

const MarksheetManagement = () => {
  // State for the marksheet form inputs
  const [form, setForm] = useState({
    session: '', // Academic session ID
    classId: '', // Class ID
    sectionId: '', // Section ID
    examId: '', // Exam ID
    studentId: '', // Student ID
    remarks: '', // General remarks for the marksheet
    subjects: [{ ...defaultSubject }] // Array of subjects with their marks
  });

  // States for dropdown data
  const [classes, setClasses] = useState([]); // List of available classes
  const [sections, setSections] = useState([]); // List of available sections
  const [students, setStudents] = useState([]); // List of available students
  const [exams, setExams] = useState([]); // List of available exams
  const [sessions, setSessions] = useState([]); // List of available academic sessions
  const [subjects, setSubjects] = useState([]); // List of subjects for the selected class/section

  // States for marksheet list and UI control
  const [items, setItems] = useState([]); // List of marksheets displayed in the table
  const [filters, setFilters] = useState({ classId: '', studentId: '', examId: '', session: '' }); // Filters for the marksheet list
  const [editingId, setEditingId] = useState(null); // ID of the marksheet being edited (null if creating new)
  const [loading, setLoading] = useState(false); // Loading state for API calls
  const [submitAttempted, setSubmitAttempted] = useState(false); // Tracks if form submission has been attempted for validation feedback

  // Memoized calculations for totals, grade, and status based on subjects
  const totals = useMemo(() => computeTotals(form.subjects), [form.subjects]); // Total marks, max marks, and percentage
  const overallGrade = useMemo(() => gradeFromPercentage(totals.percentage), [totals]); // Overall grade
  const status = useMemo(() => statusFromPercentage(totals.percentage), [totals]); // Pass/Fail status

  // Derived state for form submission button
  const isStudentValid = form.studentId && students.some(s => s._id === form.studentId); // Check if selected student is valid
  const isSubmitDisabled = !form.classId || !form.examId || !form.session || !isStudentValid || loading; // More comprehensive validation

  // useEffect to load initial dropdown data (classes, students, exams, sessions) on component mount
  useEffect(() => {
    const loadInitial = async () => {
      try {
        const schoolId = localStorage.getItem('schoolId');
        const userRole = localStorage.getItem('role');
        const studentParams = {};
        if (schoolId) studentParams.schoolId = schoolId;
        // Only apply teacherId filter for teachers, not for admins/staff
        if (userRole === 'teacher') {
          const teacherId = localStorage.getItem('teacherId');
          if (teacherId) studentParams.teacherId = teacherId;
        }
        console.log('Initial student fetch params:', studentParams, 'userRole:', userRole);

        const [clsRes, stuRes, examRes, sesRes] = await Promise.all([
          api.getClasses(),
          api.getStudents(studentParams),
          api.getExams(),
          api.getSessions()
        ]);
        setClasses(clsRes?.data || clsRes || []);
        setStudents(stuRes?.data || stuRes || []);
        setExams(examRes?.data || examRes || []);
        setSessions(sesRes?.data || sesRes || []);
      } catch (err) {
        console.error(err);
      }
    };
    loadInitial();
  }, []);

  // useEffect to load sections automatically when the classId in the form changes
  useEffect(() => {
    const loadSections = async () => {
      if (!form.classId) return setSections([]); // Clear sections if no class is selected
      try {
        const res = await api.getSections(form.classId, localStorage.getItem('schoolId'));
        setSections(res?.data || res || []);
      } catch (err) {
        console.error('Error loading sections:', err); // Log errors, but don't block UI
      }
    };
    loadSections();
  }, [form.classId]); // Rerun when form.classId changes

  // useEffect to load students and subjects based on selected session, class, and section
  useEffect(() => {
    const loadStudentsAndSubjects = async () => {
      // Only proceed if classId is selected (session is optional for broader search)
      if (!form.classId) {
        setStudents([]);
        setSubjects([]);
        return;
      }

      try {
        const schoolId = localStorage.getItem('schoolId');
        const userRole = localStorage.getItem('role');
        const params = {};
        if (form.classId) params.classId = form.classId;
        // Find the selected section by ID and use its name for filtering students
        const selectedSection = sections.find(s => (s._id || s.id) === form.sectionId);
        if (form.sectionId && selectedSection) params.section = selectedSection.name || selectedSection.sectionName;
        if (form.session) params.academicYear = form.session;
        if (schoolId) params.schoolId = schoolId;
        
        // For teachers, use the same endpoint as Attendance Management
        let newStudents = [];
        if (userRole === 'teacher') {
          const teacherId = localStorage.getItem('teacherId');
          if (teacherId) {
            console.log('Fetching students using teacher endpoint like Attendance:', { teacherId, schoolId });
            try {
              // Use the same endpoint as Attendance Management
              const response = await fetch(`${import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'}/api/students/teacher/${teacherId}/students?schoolId=${schoolId}`, {
                headers: {
                  'Authorization': `Bearer ${localStorage.getItem('token')}`,
                  'Content-Type': 'application/json'
                }
              });
              const data = await response.json();
              let allTeacherStudents = data.students || [];
              
              // Filter by class and section if specified
              if (form.classId || selectedSection) {
                allTeacherStudents = allTeacherStudents.filter(student => {
                  let matchesClass = true;
                  let matchesSection = true;
                  
                  if (form.classId) {
                    matchesClass = (student.classId?._id || student.classId) === form.classId;
                  }
                  
                  if (selectedSection) {
                    const sectionName = selectedSection.name || selectedSection.sectionName;
                    matchesSection = student.sectionId?.name === sectionName || 
                                   student.sectionName === sectionName || 
                                   student.section === sectionName;
                  }
                  
                  return matchesClass && matchesSection;
                });
              }
              
              newStudents = allTeacherStudents;
              console.log('Filtered teacher students:', newStudents.length);
            } catch (error) {
              console.error('Error fetching teacher students:', error);
              // Fallback to original method
              const paramsWithTeacher = { ...params, teacherId };
              console.log('Fallback: Fetching students with teacherId filter:', paramsWithTeacher);
              const stuResWithTeacher = await api.getStudents(paramsWithTeacher);
              newStudents = stuResWithTeacher?.data || stuResWithTeacher || [];
            }
          } else {
            const stuRes = await api.getStudents(params);
            newStudents = stuRes?.data || stuRes || [];
          }
        } else {
          // For admins/staff, fetch all students without teacherId filter
          console.log('Fetching students without teacherId filter (admin/staff):', params);
          const stuRes = await api.getStudents(params);
          newStudents = stuRes?.data || stuRes || [];
        }

        console.log('Found students:', newStudents.length);
        console.log('Student details:', newStudents.map(s => ({ 
          name: s.name, 
          _id: s._id, 
          classId: s.classId, 
          sectionId: s.sectionId,
          sectionName: s.sectionId?.name || s.sectionId?.sectionName 
        })));
        setStudents(newStudents);

        // Fetch subjects - try with sectionId first, then without if none found
        let newSubjects = [];
        if (form.sectionId) {
          const subResWithSection = await api.getSubjects(form.classId, form.sectionId, schoolId);
          newSubjects = subResWithSection?.data || subResWithSection || [];
        }
        
        // If no subjects found with section filter, try without section
        if (newSubjects.length === 0) {
          const subRes = await api.getSubjects(form.classId, null, schoolId);
          newSubjects = subRes?.data || subRes || [];
        }
        
        console.log('Found subjects:', newSubjects.length);
        setSubjects(newSubjects);

        // If the currently selected student is no longer in the filtered list, clear studentId
        if (form.studentId && !newStudents.some(s => s._id === form.studentId)) {
          setForm(f => ({ ...f, studentId: '' }));
        }
      } catch (err) {
        console.error('Error loading students and subjects:', err);
      }
    };
    loadStudentsAndSubjects();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.classId, form.sectionId, sections]); // Removed form.session dependency to allow broader search

  // Function to load the list of marksheets based on current filters
  const loadList = async () => {
    setLoading(true); // Set loading state to true
    try {
      const res = await api.listMarksheets({ ...filters }); // Fetch marksheets with current filters
      setItems(res?.data || res?.data === undefined ? (res?.data || []) : (res?.data || [])); // Update marksheet list
    } catch (err) {
      console.error(err); // Log any errors during list loading
    } finally {
      setLoading(false); // Set loading state to false
    }
  };

  // useEffect to load the marksheet list on component mount
  useEffect(() => {
    loadList();
  }, []); // Empty dependency array ensures this runs only once on mount

  // Handler for changing subject details (e.g., marks obtained, max marks)
  const handleSubjectChange = (idx, key, val) => {
    setForm((prev) => {
      const next = { ...prev };
      next.subjects = next.subjects.map((s, i) => (i === idx ? { ...s, [key]: val } : s));
      return next;
    });
  };

  // Adds a new subject row to the form
  const addSubject = () => setForm((p) => ({ ...p, subjects: [...p.subjects, { ...defaultSubject }] }));
  // Removes a subject row from the form
  const removeSubject = (idx) => setForm((p) => ({ ...p, subjects: p.subjects.filter((_, i) => i !== idx) }));

  // Resets the form to its initial state
  const resetForm = () => {
    setEditingId(null); // Clear editing ID
    setForm({ session: '', classId: '', sectionId: '', examId: '', studentId: '', remarks: '', subjects: [{ ...defaultSubject }] }); // Reset form fields
    setSubmitAttempted(false); // Reset submit attempted flag
  };

  // Handles form submission (create or update marksheet)
  const submit = async (e) => {
    e.preventDefault(); // Prevent default form submission behavior
    setSubmitAttempted(true); // Mark that submission has been attempted
    const errorMsg = validateForm(form, students); // Validate form data
    if (errorMsg) {
      toast.error(errorMsg); // Display validation error
      return;
    }
    try {
      const payload = { ...form };
      if (!payload.session) payload.session = new Date().getFullYear().toString(); // Default session if not provided
      if (editingId) {
        await api.updateMarksheet(editingId, payload); // Update existing marksheet
      } else {
        await api.createMarksheet(payload); // Create new marksheet
      }
      toast.success(editingId ? 'Updated' : 'Created'); // Display success message
      resetForm(); // Reset form after successful submission
      loadList(); // Reload marksheet list
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed'); // Display error message
    }
  };

  // Populates the form with data of an item to be edited
  const editItem = (item) => {
    setEditingId(item._id); // Set editing ID
    setForm({
      session: item.session,
      classId: item.classId?._id || item.classId,
      sectionId: item.sectionId?._id || item.sectionId,
      examId: item.examId?._id || item.examId,
      studentId: item.studentId?._id || item.studentId,
      remarks: item.remarks || '',
      subjects: item.subjects.map((s) => ({ subjectId: s.subjectId, subjectName: s.subjectName, maxMarks: s.maxMarks, passingMarks: s.passingMarks, marksObtained: s.marksObtained }))
    });
  };

  // Deletes a marksheet
  const delItem = async (id) => {
    if (!confirm('Delete marksheet?')) return; // Confirm deletion with user
    try {
      await api.deleteMarksheet(id); // Call API to delete marksheet
      toast.success('Deleted'); // Display success message
      loadList(); // Reload marksheet list
    } catch (err) {
      toast.error('Delete failed'); // Display error message
    }
  };

  // Downloads a marksheet as a PDF
  const downloadPdf = async (id) => {
    try {
      const blob = await api.downloadMarksheetPdf(id); // Fetch PDF as a blob
      const url = window.URL.createObjectURL(blob); // Create a URL for the blob
      const a = document.createElement('a'); // Create a temporary anchor element
      a.href = url;
      a.download = `marksheet-${id}.pdf`; // Set download filename
      document.body.appendChild(a); // Append to body
      a.click(); // Programmatically click to trigger download
      a.remove(); // Remove the anchor element
      window.URL.revokeObjectURL(url); // Revoke the object URL
    } catch (err) {
      toast.error('PDF download failed'); // Display error message
    }
  };

  // Handler for student selection change
  const onStudentChange = (studentId) => {
    setForm((p) => ({ ...p, studentId })); // Update studentId in form state
  };

  return (
    <div className="space-y-6">
      {/* Main container for the marksheet management page */}
      <div className="bg-white rounded-lg shadow p-5">
        {/* Title for the form, dynamically changes based on whether a marksheet is being edited or created */}
        <h2 className="text-lg font-semibold mb-4">{editingId ? 'Edit Marksheet' : 'Create Marksheet'}</h2>
        {/* Marksheet creation/editing form */}
        <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Student Selection */}
          <div>
            <label className="block text-sm mb-1">Student <span className="text-red-600">*</span></label>
            <select
              value={form.studentId}
              onChange={(e) => onStudentChange(e.target.value)}
              disabled={!form.classId || students.length === 0}
              className={`w-full border rounded px-3 py-2 disabled:bg-gray-100 disabled:text-gray-400${submitAttempted && !form.studentId ? ' border-red-500' : ''}`}
            >
              <option value="">{!form.classId ? 'Select class first' : (students.length === 0 ? 'No students available' : 'Select student')}</option>
              {students.map((s) => (
                <option key={s._id} value={s._id}>{s.name} {s.rollNumber ? `(Roll ${s.rollNumber})` : ''} {s.classId?.className ? `- ${s.classId.className}` : ''} {s.sectionId?.name ? `${s.sectionId.name}` : ''}</option>
              ))}
            </select>
            {students.length === 0 && form.classId && <div className="text-red-600 text-xs mt-1">No students available for this class. Try selecting a different class or contact admin.</div>}
            {submitAttempted && !form.studentId && <div className="text-red-600 text-xs mt-1">Student is required.</div>}
          </div>
          {/* Session Selection */}
          <div>
            <label className="block text-sm mb-1">Session <span className="text-red-600">*</span></label>
            <select
              value={form.session}
              onChange={(e) => {
                const newSession = e.target.value;
                setForm((prev) => ({
                  ...prev,
                  session: newSession,
                  studentId: newSession !== prev.session ? '' : prev.studentId // Clear student if session changes
                }));
              }}
              className={`w-full border rounded px-3 py-2${submitAttempted && !form.session ? ' border-red-500' : ''}`}
            >
              <option value="">Select session</option>
              {sessions.map((s) => (
                <option key={s._id} value={s.yearRange}>{s.yearRange}</option>
              ))}
            </select>
            {submitAttempted && !form.session && <div className="text-red-600 text-xs mt-1">Session is required.</div>}
          </div>
          {/* Class Selection */}
          <div>
            <label className="block text-sm mb-1">Class <span className="text-red-600">*</span></label>
            <select
              value={form.classId}
              onChange={(e) => {
                const newClassId = e.target.value;
                setForm((prev) => ({
                  ...prev,
                  classId: newClassId,
                  sectionId: '', // Clear section when class changes
                  studentId: newClassId !== prev.classId ? '' : prev.studentId // Clear student if class changes
                }));
              }}
              className={`w-full border rounded px-3 py-2${submitAttempted && !form.classId ? ' border-red-500' : ''}`}
            >
              <option value="">Select class</option>
              {classes.map((c) => (
                <option key={c._id} value={c._id}>{c.className}</option>
              ))}
            </select>
            {submitAttempted && !form.classId && <div className="text-red-600 text-xs mt-1">Class is required.</div>}
          </div>
          {/* Section Selection */}
          <div>
            <label className="block text-sm mb-1">Section <span className="text-red-600">*</span></label>
            <select
              value={form.sectionId}
              onChange={(e) => {
                const newSectionId = e.target.value;
                setForm((prev) => ({
                  ...prev,
                  sectionId: newSectionId,
                  studentId: newSectionId !== prev.sectionId ? '' : prev.studentId // Clear student if section changes
                }));
              }}
              disabled={!form.classId}
              className={`w-full border rounded px-3 py-2 disabled:bg-gray-100 disabled:text-gray-400${submitAttempted && !form.sectionId ? ' border-red-500' : ''}`}
            >
              <option value="">Select section</option>
              {sections.map((s) => (
                <option key={s._id || s.id} value={s._id || s.id}>{s.name || s.sectionName}</option>
              ))}
            </select>
            {submitAttempted && !form.sectionId && <div className="text-red-600 text-xs mt-1">Section is required.</div>}
          </div>
          
          {/* Exam Selection */}
          <div>
            <label className="block text-sm mb-1">Exam <span className="text-red-600">*</span></label>
            <select
              value={form.examId}
              onChange={(e) => setForm({ ...form, examId: e.target.value })}
              className={`w-full border rounded px-3 py-2${submitAttempted && !form.examId ? ' border-red-500' : ''}`}
            >
              <option value="">Select exam</option>
              {exams.map((x) => (
                <option key={x._id} value={x._id}>{x.title}</option>
              ))}
            </select>
            {submitAttempted && !form.examId && <div className="text-red-600 text-xs mt-1">Exam is required.</div>}
          </div>
          {/* Remarks Input */}
          <div className="md:col-span-2">
            <label className="block text-sm mb-1">Remarks</label>
            <input value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} className="w-full border rounded px-3 py-2" />
          </div>

          {/* Subjects and Marks Section */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium">Subjects & Marks</h3>
              <button type="button" onClick={addSubject} className="px-3 py-1 bg-blue-600 text-white rounded">Add Subject</button>
            </div>
            <div className="space-y-3">
              {form.subjects.map((s, idx) => (
                <div key={idx} className="grid grid-cols-1 md:grid-cols-5 gap-2">
                  {/* Subject Selection */}
                  <select value={s.subjectId} onChange={(e) => {
                    const selectedSubject = subjects.find(sub => (sub._id || sub.name) === e.target.value);
                    handleSubjectChange(idx, 'subjectId', e.target.value);
                    handleSubjectChange(idx, 'subjectName', selectedSubject ? selectedSubject.name : '');
                  }} className="border rounded px-3 py-2">
                    <option value="">Subject</option>
                    {subjects.map((sub) => (
                      <option key={sub._id || sub.name} value={sub._id || sub.name}>{sub.name}</option>
                    ))}
                  </select>
                  {/* Max Marks Input */}
                  <input type="number" value={s.maxMarks} onChange={(e) => handleSubjectChange(idx, 'maxMarks', Number(e.target.value))} placeholder="Max marks" className="border rounded px-3 py-2" />
                  {/* Passing Marks Input */}
                  <input type="number" value={s.passingMarks} onChange={(e) => handleSubjectChange(idx, 'passingMarks', Number(e.target.value))} placeholder="Passing marks" className="border rounded px-3 py-2" />
                  {/* Marks Obtained Input */}
                  <input type="number" value={s.marksObtained} onChange={(e) => handleSubjectChange(idx, 'marksObtained', Number(e.target.value))} placeholder="Obtained" className="border rounded px-3 py-2" />
                  {/* Remove Subject Button */}
                  <div className="flex items-center gap-2">
                    <button type="button" onClick={() => removeSubject(idx)} className="px-3 py-2 bg-red-600 text-white rounded w-full md:w-auto">Remove</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Totals, Percentage, Grade, Status Display */}
          <div className="md:col-span-2 grid grid-cols-2 md:grid-cols-4 gap-4 bg-gray-50 p-3 rounded">
            <div><span className="text-sm text-gray-600">Total</span><div className="font-semibold">{totals.totalObtained}/{totals.totalMaxMarks}</div></div>
            <div><span className="text-sm text-gray-600">Percentage</span><div className="font-semibold">{totals.percentage}%</div></div>
            <div><span className="text-sm text-gray-600">Grade</span><div className="font-semibold">{overallGrade}</div></div>
            <div><span className="text-sm text-gray-600">Status</span><div className="font-semibold">{status}</div></div>
          </div>

          {/* Form Action Buttons */}
          <div className="md:col-span-2 flex gap-3">
            <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded disabled:opacity-50" disabled={isSubmitDisabled}>{editingId ? 'Update' : 'Save'}</button>
            {editingId && (
              <button type="button" onClick={resetForm} className="px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
            )}
          </div>
        </form>
      </div>

      <MarksheetList
        items={items}
        loading={loading}
        filters={filters}
        setFilters={setFilters}
        classes={classes}
        students={students}
        exams={exams}
        loadList={loadList}
        editItem={editItem}
        delItem={delItem}
        downloadPdf={downloadPdf}
      />
    </div>
  );
};

export default MarksheetManagement;
