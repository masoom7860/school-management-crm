import { useEffect, useState } from 'react';
import jwtDecode from 'jwt-decode';
import { LucideEdit, LucideTrash2, Plus, Minus } from 'lucide-react';
import { toast } from 'react-hot-toast';
import React from 'react';
import { 
  getClasses, 
  getClassById, 
  createClass, 
  updateClass, 
  deleteClass,
  getSectionsByClass,
  addSectionToClass,
  updateSectionInClass,
  deleteSectionFromClass
} from '../../api/classesApi';

const ClassManagement = () => {
  const [classes, setClasses] = useState([]);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [formData, setFormData] = useState({
    className: '',
  });
  const [formErrors, setFormErrors] = useState({});
  const [editClassId, setEditClassId] = useState(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState(null);
  const [loading, setLoading] = useState(true); // Add loading state for initial fetch
  const [actionLoading, setActionLoading] = useState(false); // Add loading state for actions (create, update, delete)

  const [token, setToken] = useState(null);
  const [schoolId, setSchoolId] = useState('');
  const [userId, setUserId] = useState(''); // Use userId from token

  const [expandedClassId, setExpandedClassId] = useState(null);
  const [sections, setSections] = useState([]);
  const [sectionForm, setSectionForm] = useState({ name: '', sectionId: null, originalName: '' });
  const [sectionLoading, setSectionLoading] = useState(false);
  const [allSections, setAllSections] = useState({}); // New state to store all sections by classId

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (!storedToken) {
      toast.error("Authentication token not found. Please log in again.");
      setLoading(false);
      return;
    }
    setToken(storedToken);

    try {
      const decoded = jwtDecode(storedToken);
      setSchoolId(decoded.schoolId);
      setUserId(decoded.id); // Assuming user ID is in 'id' field
    } catch (err) {
      console.error('Failed to decode token:', err);
      toast.error("Invalid authentication token. Please log in again.");
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (schoolId && token) {
      fetchClasses();
    }
  }, [schoolId, token]); // Depend on schoolId and token

  useEffect(() => {
    if (classes.length > 0 && schoolId && token) {
      const fetchAllSections = async () => {
        const sectionMap = {};
        for (const cls of classes) {
          try {
            const response = await getSectionsByClass(cls._id, schoolId);
            sectionMap[cls._id] = response.data || [];
            console.log(`Sections for class ${cls.className}:`, sectionMap[cls._id]);
          } catch (error) {
            console.error(`Error fetching sections for class ${cls.className}:`, error);
            sectionMap[cls._id] = [];
          }
        }
        setAllSections(sectionMap);
        console.log('All sections map:', sectionMap);
      };
      fetchAllSections();
    }
  }, [classes, schoolId, token]);

  const fetchClasses = async () => {
    setLoading(true);
    try {
      setClasses([]);
      const response = await getClasses();
      setClasses(response.data || []);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching classes:', err);
      toast.error('Error fetching classes: ' + (err.message || 'Unknown error'));
      setLoading(false);
    }
  };

  const fetchClassById = async (id) => {
    setActionLoading(true);
    try {
      const response = await getClassById(id);
      const data = response.class;
      setFormData({
        className: data.className || '',
      });
      setEditClassId(id);
      setFormOpen(true);
    } catch (err) {
      console.error('Error fetching class by ID:', err);
      toast.error('Error fetching class: ' + (err.message || 'Unknown error'));
    } finally {
      setActionLoading(false);
    }
  };

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setFormErrors((prev) => ({ ...prev, [e.target.name]: '' }));
  };

  const handleSectionInputChange = (idx, value) => {
    const updatedSections = [...formData.sections];
    updatedSections[idx] = value;
    setFormData({ ...formData, sections: updatedSections });
    setFormErrors((prev) => ({ ...prev, sections: '' }));
  };

  const handleAddSectionField = () => {
    setFormData({ ...formData, sections: [...formData.sections, ''] });
  };

  const handleRemoveSectionField = (idx) => {
    const updatedSections = formData.sections.filter((_, i) => i !== idx);
    setFormData({ ...formData, sections: updatedSections });
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.className.trim()) {
      errors.className = 'Class Name is required';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleCreateClass = async () => {
    if (!validateForm()) {
      toast.error('Please fix the errors in the form.');
      return;
    }
    setActionLoading(true);
    try {
      await createClass({ className: formData.className });
      fetchClasses();
      setFormData({ className: '' });
      setFormErrors({});
      setFormOpen(false);
      toast.success('Class created successfully!');
    } catch (err) {
      console.error('Failed to create class:', err);
      toast.error('Failed to create class: ' + (err.message || 'Unknown error'));
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateClass = async () => {
    if (!validateForm()) {
      toast.error('Please fix the errors in the form.');
      return;
    }
    setActionLoading(true);
    try {
      await updateClass(editClassId, { className: formData.className });
      fetchClasses();
      setFormData({ className: '' });
      setFormErrors({});
      setFormOpen(false);
      setEditClassId(null);
      toast.success('Class updated successfully!');
    } catch (err) {
      console.error('Failed to update class:', err);
      toast.error('Failed to update class: ' + (err.message || 'Unknown error'));
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteClass = async (id) => {
    setActionLoading(true);
    try {
      await deleteClass(id);
      fetchClasses();
      setDeleteConfirmId(null);
      toast.success('Class deleted successfully!');
    } catch (err) {
      console.error('Failed to delete class:', err);
      toast.error('Failed to delete class: ' + (err.message || 'Unknown error'));
    } finally {
      setActionLoading(false);
    }
  };

  const filteredClasses = classes.filter((c) =>
    c.className?.toLowerCase().includes(search.toLowerCase())
  );

  // Fetch sections for a class
  const fetchSections = async (classId) => {
    setSectionLoading(true);
    try {
      console.log('Fetching sections for classId:', classId);
      const response = await getSectionsByClass(classId, schoolId);
      console.log('Sections API response:', response);
      const sectionsData = response.data || [];
      console.log('Processed sections data:', sectionsData);
      setSections(sectionsData);
    } catch (err) {
      console.error('Error fetching sections:', err);
      toast.error('Error fetching sections');
      setSections([]);
    } finally {
      setSectionLoading(false);
    }
  };

  // Open section manager for a class
  const handleExpandSections = (classId) => {
    console.log('handleExpandSections called with classId:', classId);
    console.log('Current sections state:', sections);
    if (expandedClassId === classId) {
      setExpandedClassId(null);
      setSections([]);
    } else {
      setExpandedClassId(classId);
      fetchSections(classId);
    }
    setSectionForm({ name: '', sectionId: null, originalName: '' });
  };

  // Add or update section
  const handleSectionSubmit = async (e) => {
    e.preventDefault();
    if (!sectionForm.name.trim()) {
      toast.error('Section name required');
      return;
    }
    setSectionLoading(true);
    try {
      if (sectionForm.sectionId) {
        // Update section
        await updateSectionInClass(expandedClassId, sectionForm.originalName, { 
          name: sectionForm.name 
        });
        toast.success('Section updated');
      } else {
        // Create section
        await addSectionToClass(expandedClassId, {
          name: sectionForm.name,
        });
        toast.success('Section added');
      }
      fetchSections(expandedClassId);
      setSectionForm({ name: '', sectionId: null, originalName: '' });
    } catch (err) {
      console.error('Error saving section:', err);
      toast.error('Error saving section');
    } finally {
      setSectionLoading(false);
    }
  };

  // Edit section
  const handleEditSection = (section) => {
    setSectionForm({ 
      name: section.name, 
      sectionId: section._id,
      originalName: section.name // Store original name for update
    });
  };

  // Delete section
  const handleDeleteSection = async (sectionId) => {
    setSectionLoading(true);
    try {
      // Find the section to get its name for the delete endpoint
      const section = sections.find(s => s._id === sectionId);
      if (!section) {
        toast.error('Section not found');
        return;
      }
      
      await deleteSectionFromClass(expandedClassId, section.name);
      toast.success('Section deleted');
      fetchSections(expandedClassId);
    } catch (err) {
      console.error('Error deleting section:', err);
      toast.error('Error deleting section');
    } finally {
      setSectionLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Search Bar */}
      <div className="w-full max-w-md">
        <input
          className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Search classes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Create Class Section */}
      {formOpen && (
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            {editClassId ? 'Update Class' : 'Create Class'}
          </h2>
          <div className="space-y-4">
            <div>
              <label htmlFor="className" className="block text-sm font-medium text-gray-700 mb-1">
                Class Name
              </label>
              <input
                id="className"
                name="className"
                type="text"
                placeholder="e.g., 10th"
                className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                  formErrors.className ? 'border-red-500' : ''
                }`}
                value={formData.className}
                onChange={handleInputChange}
              />
              {formErrors.className && (
                <p className="mt-1 text-sm text-red-600">{formErrors.className}</p>
              )}
            </div>
            <div className="flex gap-3">
              <button
                onClick={editClassId ? handleUpdateClass : handleCreateClass}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={actionLoading}
              >
                {actionLoading ? (editClassId ? 'Updating...' : 'Creating...') : (editClassId ? 'Update' : 'Create')}
              </button>
              <button
                onClick={() => {
                  setFormOpen(false);
                  setFormErrors({});
                  setEditClassId(null);
                  setFormData({ className: '' });
                }}
                className="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={actionLoading}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Class Button - Only show when form is not open */}
      {!formOpen && (
        <div className="flex justify-end">
          <button
            onClick={() => {
              setFormOpen(true);
              setFormData({ className: '' });
              setFormErrors({});
              setEditClassId(null);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <Plus className="w-5 h-5" />
            Add Class
          </button>
        </div>
      )}

      {loading && !actionLoading && !formOpen ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading classes...</p>
        </div>
      ) : filteredClasses.length === 0 && !loading && !actionLoading ? (
        <div className="text-center py-8">
          <p className="text-gray-500">No classes found.</p>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  CLASS NAME
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  SECTIONS
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ACTIONS
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredClasses.map((classItem) => (
                <React.Fragment key={classItem._id}>
                  <tr className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {classItem.className || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      {allSections[classItem._id] && allSections[classItem._id].length > 0
                        ? (
                          <div className="flex flex-wrap gap-1">
                            {allSections[classItem._id].map(section => (
                              <span key={section._id} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">
                                {section.name}
                              </span>
                            ))}
                          </div>
                        )
                        : (
                          <div className="text-gray-400 text-xs">
                            {allSections[classItem._id] ? 'No sections' : 'Loading...'}
                          </div>
                        )
                      }
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={() => fetchClassById(classItem._id)}
                          className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-100"
                          disabled={actionLoading}
                          title="Edit Class"
                        >
                          <LucideEdit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleExpandSections(classItem._id)}
                          className={`px-3 py-1 rounded text-xs font-medium ${
                            expandedClassId === classItem._id 
                              ? 'bg-blue-700 text-white' 
                              : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                          }`}
                          disabled={actionLoading}
                        >
                          {expandedClassId === classItem._id ? 'Hide Sections' : 'Manage Sections'}
                        </button>
                        {deleteConfirmId === classItem._id ? (
                          <>
                            <button
                              onClick={() => handleDeleteClass(classItem._id)}
                              className="px-2 py-1 text-xs text-white bg-red-600 rounded hover:bg-red-700"
                              disabled={actionLoading}
                            >
                              Confirm
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-2 py-1 text-xs bg-gray-400 text-white rounded hover:bg-gray-500"
                              disabled={actionLoading}
                            >
                              Cancel
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmId(classItem._id)}
                            className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-100"
                            disabled={actionLoading}
                            title="Delete Class"
                          >
                            <LucideTrash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                  {/* Section Management UI */}
                  {expandedClassId === classItem._id && (
                    <tr>
                      <td colSpan={2} className="bg-gray-50 px-6 py-4">
                        <div className="space-y-2">
                          <h4 className="font-semibold text-gray-700 mb-2">Sections</h4>
                          {sectionLoading ? (
                            <div>Loading sections...</div>
                          ) : (
                            <>
                              {sections.length === 0 ? (
                                <div className="text-gray-500">No sections found for this class.</div>
                              ) : (
                                <div className="overflow-x-auto">
                                  <table className="min-w-full bg-white border border-gray-200">
                                    <thead className="bg-gray-50">
                                      <tr>
                                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b">
                                          Section Name
                                        </th>
                                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b">
                                          Actions
                                        </th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200">
                                      {Array.isArray(sections) && sections.map((section) => (
                                        <tr key={section._id} className="hover:bg-gray-50">
                                          <td className="px-4 py-3 text-sm text-gray-900 border-b">
                                            {section.name}
                                          </td>
                                          <td className="px-4 py-3 text-sm text-gray-900 border-b">
                                            <div className="flex space-x-2">
                                              <button
                                                onClick={() => handleEditSection(section)}
                                                className="text-green-600 hover:text-green-900 p-1 rounded hover:bg-green-100"
                                                disabled={sectionLoading}
                                                title="Edit Section"
                                              >
                                                <LucideEdit className="w-4 h-4" />
                                              </button>
                                              <button
                                                onClick={() => handleDeleteSection(section._id)}
                                                className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-100"
                                                disabled={sectionLoading}
                                                title="Delete Section"
                                              >
                                                <LucideTrash2 className="w-4 h-4" />
                                              </button>
                                            </div>
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              )}
                              {/* Section Add/Edit Form */}
                              <form onSubmit={handleSectionSubmit} className="flex gap-2 mt-3">
                                <input
                                  type="text"
                                  placeholder="Section name (e.g., A)"
                                  className="p-2 border rounded w-40"
                                  value={sectionForm.name}
                                  onChange={e => setSectionForm({ ...sectionForm, name: e.target.value })}
                                  disabled={sectionLoading}
                                />
                                <button
                                  type="submit"
                                  className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                                  disabled={sectionLoading}
                                >
                                  {sectionForm.sectionId ? 'Update Section' : 'Add Section'}
                                </button>
                                {sectionForm.sectionId && (
                                  <button
                                    type="button"
                                    onClick={() => setSectionForm({ name: '', sectionId: null })}
                                    className="px-3 py-1 bg-gray-400 text-white rounded hover:bg-gray-500"
                                    disabled={sectionLoading}
                                  >
                                    Cancel
                                  </button>
                                )}
                              </form>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ClassManagement;
 