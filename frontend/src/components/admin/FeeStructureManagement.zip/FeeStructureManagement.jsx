import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { Download, Plus, Minus, Edit, Trash2, ChevronUp, ChevronDown, Copy } from 'lucide-react';
// import AcademicYearSelector from '../../components/common/AcademicYearSelector'; // Assuming this component exists // Commented out as file not found
import useSchoolClasses from '../../hooks/useSchoolClasses'; // Assuming this hook exists
import { getFeeStructures, createFeeStructure, updateFeeStructure, deleteFeeStructure } from '../../api/feeStructureApi';
import { getSessions } from '../../api/sessionsApi';
// import {navigate} from 'react-router-dom';
// import { useNavigate } from 'react-router-dom';


const ConfirmationModal = ({ isOpen, onClose, onConfirm, title, message, confirmText, cancelText, danger }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div className="mt-3 text-center">
          <h3 className="text-lg leading-6 font-medium text-gray-900">{title}</h3>
          <div className="mt-2 px-7 py-3">
            <p className="text-sm text-gray-500">
              {message}
            </p>
          </div>
          <div className="items-center px-4 py-3">
            <button
              id="confirm-btn"
              className={`px-4 py-2 ${danger ? 'bg-red-600 hover:bg-red-700' : 'bg-red-600 hover:bg-red-700'} text-white text-base font-medium rounded-md w-full shadow-sm focus:outline-none focus:ring-2 focus:ring-red-300`}
              onClick={onConfirm}
            >
              {confirmText}
            </button>
            <button
              id="cancel-btn"
              className="mt-3 px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 text-base font-medium rounded-md w-full shadow-sm focus:outline-none focus:ring-2 focus:ring-gray-300"
              onClick={onClose}
            >
              {cancelText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const FeeStructureManagement = () => {
  const navigate = useNavigate();
  const [feeStructures, setFeeStructures] = useState([]);
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [formData, setFormData] = useState({
    classId: '',
    sectionId: '',
    academicYear: '',
    name: '',
    description: '',
    frequency: 'yearly',
    dueDate: '',
    isActive: true,
    components: []
  });
  const [selectedFeeNames, setSelectedFeeNames] = useState([]);
  const [formErrors, setFormErrors] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [schoolId, setSchoolId] = useState('');
  const [expandedStructure, setExpandedStructure] = useState(null);
  const [filter, setFilter] = useState({
    classId: '',
    sectionId: '',
    academicYear: '',
    isActive: '',
    frequency: ''
  });
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [structureToDelete, setStructureToDelete] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sessions, setSessions] = useState([]);
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [loadingAcademicYears, setLoadingAcademicYears] = useState(false);
  const [academicYears, setAcademicYears] = useState([]);

  const { 
    classes, 
    loading: classesLoading, 
    sections, 
    getSectionsByClassId,
    getSectionOptions,
  } = useSchoolClasses();
  
  const [filterSections, setFilterSections] = useState([]);
  const [formSections, setFormSections] = useState([]);

  // Predefined fee structure names with unique IDs
  const predefinedFeeNames = [
    { id: 'admission', name: 'Admission Fee' },
    { id: 'tuition', name: 'Tuition Fee' },
    { id: 'examination', name: 'Examination Fee' },
    { id: 'lab', name: 'Lab Fee' },
    { id: 'library', name: 'Library Fee' },
    { id: 'transport', name: 'Transport Fee' },
    { id: 'hostel', name: 'Hostel Fee' },
    { id: 'sports', name: 'Sports Fee' },
    { id: 'miscellaneous', name: 'Miscellaneous / Activity Fee' }
  ];

  // Handle fee name selection
  const handleFeeNameSelect = (feeName) => {
    setSelectedFeeNames(prev => {
      const newSelection = (Array.isArray(prev) ? prev : []).includes(feeName.id)
        ? prev.filter(id => id !== feeName.id) // Remove if already selected
        : [...prev, feeName.id]; // Add if not selected

      // Update form data based on selection
      setFormData(prev => {
        // If we're removing the fee, filter it out
        if ((Array.isArray(prev.components) ? prev.components : []).some(comp => comp.id === feeName.id)) {
          return {
            ...prev,
            components: prev.components.filter(comp => comp.id !== feeName.id)
          };
        }
        // If we're adding the fee, add it with default values
        return {
          ...prev,
          components: [
            ...prev.components,
            {
              id: feeName.id,
              name: feeName.name,
              amount: 0,
              isTaxable: false,
              taxRate: 0,
              description: ''
            }
          ]
        };
      });

      return newSelection;
    });
  };

  // Remove component and its selection
  const handleRemoveComponent = (index) => {
    const componentToRemove = formData.components[index];
    setSelectedFeeNames(prev => prev.filter(id => id !== componentToRemove.id));
    
    setFormData(prev => ({
      ...prev,
      components: prev.components.filter((_, i) => i !== index)
    }));
  };

  // Fetch sessions on component mount
  useEffect(() => {
    const fetchSessions = async () => {
      try {
        setLoadingSessions(true);
        console.log('Fetching sessions...');
        const response = await getSessions();
        // Handle both direct array response and response.data array
        const sessionsData = Array.isArray(response) ? response : (response?.data || []);
        console.log('Sessions data from API:', sessionsData);
        setSessions(sessionsData);
      } catch (error) {
        console.error('Error fetching sessions:', error);
        toast.error('Failed to load sessions');
      } finally {
        setLoadingSessions(false);
      }
    };

    fetchSessions();
  }, []);

  // Process sessions to academic years when sessions are loaded
  useEffect(() => {
    console.log('Processing sessions to academic years. Sessions:', sessions);
    
    if (!sessions || !Array.isArray(sessions)) {
      console.log('Sessions data is not in expected format:', sessions);
      setAcademicYears([]);
      setLoadingAcademicYears(false);
      return;
    }

    if (sessions.length > 0) {
      const years = sessions.map(session => {
        // The session object comes directly from the API response
        const sessionData = session;
        
        if (!sessionData) {
          console.warn('Invalid session data:', session);
          return null;
        }

        // Use yearRange field which is the standard in SessionManagement
        const yearRange = sessionData.yearRange;

        if (!yearRange) {
          console.warn('Session is missing yearRange:', sessionData);
          return null;
        }

        const yearData = {
          value: yearRange, // Use yearRange as the value
          label: yearRange, // Show yearRange as the label
          startDate: sessionData.startDate,
          endDate: sessionData.endDate,
          isActive: sessionData.isActive || false,
          sessionId: sessionData._id // Store the session ID for reference
        };
        
        console.log('Processed session to year:', yearData);
        return yearData;
      }).filter(Boolean); // Remove any null entries from invalid sessions

      console.log('Setting academic years:', years);
      setAcademicYears(years);
      
      if (years.length === 0) {
        console.warn('No valid academic years could be extracted from sessions');
        toast('No valid academic years found in sessions data', { 
          icon: '⚠️',
          style: {
            background: '#fff3cd',
            color: '#856404',
          },
        });
      }
    } else {
      console.log('No sessions data available to process');
      setAcademicYears([]);
      toast('No academic sessions found. Please create a session first.', { 
        icon: '⚠️',
        style: {
          background: '#fff3cd',
          color: '#856404',
        },
      });
    }
    
    setLoadingAcademicYears(false);
  }, [sessions, loadingSessions]);

  // Get school ID from token
  useEffect(() => {
    if (token) {
      try {
        const decoded = JSON.parse(atob(token.split('.')[1]));
        setSchoolId(decoded.schoolId);
      } catch (error) {
        console.error('Error decoding token:', error);
        navigate('/login');
      }
    } else {
      navigate('/login');
    }
  }, [token, navigate]);

  // Fetch sections when form classId changes
  useEffect(() => {
    const loadSections = async () => {
      if (formData.classId) {
        try {
          const sections = await getSectionsByClassId(formData.classId);
          setFormSections(sections || []);
          
          // Reset sectionId if it's not in the new sections list
          if (formData.sectionId && !sections?.some(s => s._id === formData.sectionId)) {
            setFormData(prev => ({ ...prev, sectionId: '' }));
          }
        } catch (error) {
          console.error('Error loading sections:', error);
          setFormSections([]);
          setFormData(prev => ({ ...prev, sectionId: '' }));
        }
      } else {
        setFormSections([]);
        setFormData(prev => ({ ...prev, sectionId: '' }));
      }
    };
    
    loadSections();
  }, [formData.classId, schoolId, getSectionsByClassId]);

  // Fetch sections for filter when filter classId changes
  useEffect(() => {
    const loadFilterSections = async () => {
      if (filter.classId) {
        try {
          const sections = await getSectionsByClassId(filter.classId);
          setFilterSections(sections || []);
          
          // Reset sectionId if it's not in the new sections list
          if (filter.sectionId && !sections?.some(s => s._id === filter.sectionId)) {
            setFilter(prev => ({ ...prev, sectionId: '' }));
          }
        } catch (error) {
          console.error('Error loading filter sections:', error);
          setFilterSections([]);
          setFilter(prev => ({ ...prev, sectionId: '' }));
        }
      } else {
        setFilterSections([]);
        setFilter(prev => ({ ...prev, sectionId: '' }));
      }
    };
    
    loadFilterSections();
  }, [filter.classId, schoolId, getSectionsByClassId]);

  const fetchFeeStructures = useCallback(async (currentFilter, classList = []) => {
    setLoading(true);
    try {
      const response = await getFeeStructures(schoolId, currentFilter);
      const feeStructuresData = response.data || [];
      
      // Enrich fee structures with class names
      const enrichedFeeStructures = feeStructuresData.map(structure => {
        const classInfo = classList.find(cls => cls._id === structure.classId) || {};
        return {
          ...structure,
          className: classInfo.className || 'Unknown Class',
          classData: classInfo
        };
      });
      
      setFeeStructures(enrichedFeeStructures);
    } catch (error) {
      toast.error(error.message || 'Failed to fetch fee structures');
      console.error('Fetch error:', error);
    } finally {
      setLoading(false);
    }
  }, [schoolId, getFeeStructures]);

  // Fetch fee structures and classes
  useEffect(() => {
    if (schoolId && token && classes && classes.length > 0) { // Ensure token and classes are available
      const fetchData = async () => {
        try {
          // Now fetch fee structures, using classes from the hook
          await fetchFeeStructures(filter, classes);
        } catch (error)
          {console.error('Error fetching data:', error);
          toast.error('Failed to load data');
          setLoading(false);
        }
      };
      
      fetchData();
    }
  }, [schoolId, token, filter, classes]);

  // fetchSections function has been removed as it's now provided by useSchoolClasses hook

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setFormErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleComponentChange = (index, field, value) => {
    const newComponents = [...formData.components];
    newComponents[index][field] = field === 'amount' || field === 'taxRate' ? Number(value) : value;
    setFormData(prev => ({ ...prev, components: newComponents }));

    // Clear errors for this field
    setFormErrors(prev => {
      const newErrors = { ...prev };
      if (newErrors.components?.[index]) {
        newErrors.components[index][field] = '';
      }
      return newErrors;
    });
  };

  const handleAddComponent = () => {
    // Find all unselected fee names
    const unselectedFees = predefinedFeeNames.filter(
      fee => !selectedFeeNames.includes(fee.id)
    );
    
    if (unselectedFees.length > 0) {
      // Show a dropdown or modal to select which fee to add
      // For now, we'll just add the first one
      handleFeeNameSelect(unselectedFees[0]);
    } else {
      toast.warning('All available fee types have been added');
    }
  };

  const validateForm = () => {
    const errors = {};
    let isValid = true;

    if (!formData.classId) {
      errors.classId = 'Class is required';
      isValid = false;
    }

    if (!formData.academicYear) {
      errors.academicYear = 'Academic year is required';
      isValid = false;
    }

    if (!formData.name) {
      errors.name = 'Structure name is required';
      isValid = false;
    }

    if (!formData.frequency) {
      errors.frequency = 'Frequency is required';
      isValid = false;
    }

    if (formData.frequency !== 'one-time' && !formData.dueDate) {
      errors.dueDate = 'Due date is required for this frequency';
      isValid = false;
    }

    const componentErrors = [];
    formData.components.forEach((comp, index) => {
      const compError = {};
      if (!comp.name || comp.name.trim() === '') {
        compError.name = 'Component name is required';
        isValid = false;
      }
      if (isNaN(comp.amount)) {
        compError.amount = 'Amount must be a number';
        isValid = false;
      } else if (comp.amount <= 0) {
        compError.amount = 'Amount must be greater than 0';
        isValid = false;
      }
      if (comp.isTaxable && (isNaN(comp.taxRate) || comp.taxRate < 0 || comp.taxRate > 100)) {
        compError.taxRate = 'Tax rate must be between 0 and 100';
        isValid = false;
      }
      componentErrors[index] = compError;
    });

    if (componentErrors.some(err => Object.keys(err).length > 0)) {
      errors.components = componentErrors;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      const data = {
        ...formData,
        schoolId,
        totalAmount: calculateTotal(formData.components)
      };

      if (editingId) {
        // Update existing
        const response = await updateFeeStructure(editingId, data);
        toast.success(response.message);
        setFeeStructures(feeStructures.map(fs =>
          fs._id === editingId ? response.data : fs
        ));
      } else {
        // Create new
        const response = await createFeeStructure(data);
        toast.success(response.message);
        setFeeStructures([...feeStructures, response.data]);
      }

      resetForm();
    } catch (error) {
      const backendErrors = error.errors;
      const backendMessage = error.message;
      let errorMsg = backendMessage || 'Failed to save fee structure';

      if (backendErrors) {
        // Format validation errors
        const validationErrorMessages = Object.values(backendErrors)
          .map(err => err.message)
          .join(', ');
        errorMsg = `Validation failed: ${validationErrorMessages}`;
      }

      toast.error(errorMsg);
      console.error('Submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (structure) => {
    setFormData({
      classId: structure.classId._id,
      sectionId: structure.sectionId?._id || '',
      academicYear: structure.academicYear || '', // Ensure academicYear is a string
      name: structure.name || '', // Ensure name is a string
      description: structure.description || '', // Ensure description is a string
      frequency: structure.frequency || 'yearly', // Ensure frequency is a string, default to yearly
      dueDate: structure.dueDate ? structure.dueDate.split('T')[0] : '', // Already handles null/undefined
      components: structure.components || [{ name: '', amount: 0, isTaxable: false, taxRate: 0 }], // Ensure components is an array
      isActive: structure.isActive !== undefined ? structure.isActive : true // Ensure isActive is a boolean
    });
    setEditingId(structure._id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleUpdate = async (id, data) => {
    setIsSubmitting(true);
    try {
      const response = await updateFeeStructure(id, data);
      toast.success(response.message);
      setFeeStructures(feeStructures.map(fs =>
        fs._id === id ? response.data : fs
      ));
      resetForm();
    } catch (error) {
      const errorMsg = error.message || 'Failed to update fee structure';
      toast.error(errorMsg);
      console.error('Update error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDuplicate = async (structure) => {
    try {
      const newAcademicYear = prompt('Enter new academic year for the duplicate:', structure.academicYear);
      if (!newAcademicYear) return;

      const data = {
        ...structure,
        academicYear: newAcademicYear,
        name: `${structure.name} (Copy)`,
        isActive: true,
        schoolId
      };
      delete data._id;
      delete data.createdAt;
      delete data.updatedAt;
      delete data.__v;

      setLoading(true);
      const response = await createFeeStructure(data);
      toast.success('Fee structure duplicated successfully');
      setFeeStructures([...feeStructures, response.data]);
    } catch (error) {
      toast.error(error.message || 'Failed to duplicate fee structure');
    } finally {
      setLoading(false);
    }
  };

  const confirmDelete = (structure) => {
    setStructureToDelete(structure);
    setDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (!structureToDelete) return;

    setLoading(true);
    try {
      await deleteFeeStructure(structureToDelete._id);
      toast.success('Fee structure deleted successfully');
      setFeeStructures(feeStructures.filter(fs => fs._id !== structureToDelete._id));
    } catch (error) {
      toast.error(error.message || 'Failed to delete fee structure');
    } finally {
      setLoading(false);
      setDeleteModalOpen(false);
      setStructureToDelete(null);
    }
  };

  const resetForm = () => {
    setFormData({
      classId: '',
      sectionId: '',
      academicYear: '',
      name: '',
      description: '',
      frequency: 'yearly',
      dueDate: '',
      components: [{ name: '', amount: 0, isTaxable: false, taxRate: 0 }],
      isActive: true
    });
    setEditingId(null);
    setFormErrors({});
    setSections([]);
  };

  const toggleExpandStructure = (id) => {
    setExpandedStructure(expandedStructure === id ? null : id);
  };

  const calculateTotal = (components) => {
    return components.reduce((sum, comp) => {
      const amount = comp.amount || 0;
      const tax = comp.isTaxable ? amount * (comp.taxRate || 0) / 100 : 0;
      return sum + amount + tax;
    }, 0);
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilter(prev => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilter({
      classId: '',
      sectionId: '',
      academicYear: '',
      isActive: '',
      frequency: ''
    });
  };

  const exportToCSV = () => {
    // CSV export implementation
    const headers = ['Class', 'Name', 'Academic Year', 'Frequency', 'Status', 'Components', 'Total Amount'];
    const csvRows = feeStructures.map(structure => {
      const components = structure.components.map(c =>
        `${c.name}: ₹${c.amount}${c.isTaxable ? ` (+${c.taxRate}% tax)` : ''}`
      ).join('; ');
      return [
        structure.classId?.className || 'Unknown',
        structure.name,
        structure.academicYear,
        structure.frequency,
        structure.isActive ? 'Active' : 'Inactive',
        components,
        structure.totalAmount
      ].join(',');
    });

    const csvContent = [
      headers.join(','),
      ...csvRows
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('hidden', '');
    link.setAttribute('href', url);
    link.setAttribute('download', `fee_structures_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Fee Structure Management</h1>

      {/* Filter Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Filter Fee Structures</h2>
          <div className="flex gap-2">
            <button
              onClick={clearFilters}
              className="px-3 py-1 text-sm border rounded hover:bg-gray-50"
            >
              Clear Filters
            </button>
            <button
              onClick={exportToCSV}
              className="px-3 py-1 text-sm border rounded hover:bg-gray-50 flex items-center gap-1"
            >
              <Download size={16} /> Export
            </button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {/* Filter by Class */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Class</label>
            <select
              className="w-full p-2 border border-gray-300 rounded-md"
              value={filter.classId}
              onChange={(e) => setFilter({ ...filter, classId: e.target.value, sectionId: '' })}
              disabled={classesLoading}
            >
              <option value="">All Classes</option>
              {console.log('Classes in FeeStructureManagement (filter):', classes, typeof classes, Array.isArray(classes))}
              {(classes || []).map((cls) => (
                <option key={cls._id} value={cls._id}>
                  {cls.className}
                </option>
              ))}
            </select>
            {classesLoading && <p className="mt-1 text-sm text-gray-500">Loading classes...</p>}
          </div>

          {/* Filter by Section */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Section</label>
            <select
              className="w-full p-2 border border-gray-300 rounded-md"
              value={filter.sectionId}
              onChange={(e) => setFilter({ ...filter, sectionId: e.target.value })}
              disabled={!filter.classId || filterSections.length === 0}
            >
              <option value="">All Sections</option>
              {filterSections.map((section) => (
                <option key={section._id} value={section._id}>
                  {section.name}
                </option>
              ))}
            </select>
            {filter.classId && filterSections.length === 0 && (
              <p className="mt-1 text-sm text-gray-500">No sections available</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Academic Year</label>
            <select
              name="academicYear"
              className="w-full border rounded p-2"
              value={filter.academicYear}
              onChange={handleFilterChange}
              disabled={loadingAcademicYears}
            >
              <option value="">
                {loadingAcademicYears ? 'Loading academic years...' : 'All Academic Years'}
              </option>
              {academicYears.length > 0 ? (
                academicYears.map(year => (
                  <option key={year.value} value={year.value}>
                    {year.label} {year.isActive ? '(Active)' : ''}
                  </option>
                ))
              ) : (
                <option value="" disabled>No academic years available</option>
              )}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Frequency</label>
            <select
              name="frequency"
              className="w-full border rounded p-2"
              value={filter.frequency}
              onChange={handleFilterChange}
            >
              <option value="">All Frequencies</option>
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
              <option value="yearly">Yearly</option>
              <option value="one-time">One-time</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select
              name="isActive"
              className="w-full border rounded p-2"
              value={filter.isActive}
              onChange={handleFilterChange}
            >
              <option value="">All Statuses</option>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {/* Form Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">
          {editingId ? 'Edit Fee Structure' : 'Add New Fee Structure'}
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {/* Class Selection */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Class <span className="text-red-500">*</span></label>
              <select
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={formData.classId}
                onChange={(e) => setFormData({ ...formData, classId: e.target.value, sectionId: '' })}
                required
                disabled={classesLoading}
              >
                <option value="">Select Class</option>
                {console.log('Classes in FeeStructureManagement (form):', classes, typeof classes, Array.isArray(classes))}
                {(classes || []).map((cls) => (
                  <option key={cls._id} value={cls._id}>
                    {cls.className}
                  </option>
                ))}
              </select>
              {classesLoading && <p className="mt-1 text-sm text-gray-500">Loading classes...</p>}
              {formErrors.classId && <p className="mt-1 text-sm text-red-600">{formErrors.classId}</p>}
            </div>

            {/* Section Selection */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Section <span className="text-red-500">*</span>
              </label>
              <select
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                required
                disabled={!formData.classId || formSections.length === 0}
              >
                <option value="">
                  {formSections.length === 0 ? 'No sections available' : 'Select Section'}
                </option>
                {formSections.map((section) => (
                  <option key={section._id} value={section._id}>
                    {section.name}
                  </option>
                ))}
              </select>
              {formErrors.sectionId && (
                <p className="mt-1 text-sm text-red-600">{formErrors.sectionId}</p>
              )}
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Academic Year</label>
              <select
                name="academicYear"
                className={`w-full p-2 border ${formErrors.academicYear ? 'border-red-500' : 'border-gray-300'} rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                value={formData.academicYear}
                onChange={handleInputChange}
                required
                disabled={loadingAcademicYears}
              >
                <option value="">
                  {loadingAcademicYears ? 'Loading academic years...' : 'Select Academic Year'}
                </option>
                {academicYears.length > 0 ? (
                  academicYears.map(year => (
                    <option key={year.value} value={year.value}>
                      {year.label} {year.isActive ? '(Active)' : ''}
                    </option>
                  ))
                ) : (
                  <option value="">No academic years available</option>
                )}
              </select>
              {formErrors.academicYear && (
                <p className="text-red-500 text-xs mt-1">{formErrors.academicYear}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Frequency*</label>
              <select
                name="frequency"
                className={`w-full border rounded p-2 ${formErrors.frequency ? 'border-red-500' : ''}`}
                value={formData.frequency}
                onChange={handleInputChange}
              >
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="yearly">Yearly</option>
                <option value="one-time">One-time</option>
              </select>
              {formErrors.frequency && (
                <p className="text-red-500 text-sm mt-1">{formErrors.frequency}</p>
              )}
            </div>
            {formData.frequency !== 'one-time' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Due Date*</label>
                <input
                  type="date"
                  name="dueDate"
                  className={`w-full border rounded p-2 ${formErrors.dueDate ? 'border-red-500' : ''}`}
                  value={formData.dueDate}
                  onChange={handleInputChange}
                />
                {formErrors.dueDate && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.dueDate}</p>
                )}
              </div>
            )}
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Fee Structure Name*</label>
            <input
              type="text"
              name="name"
              className={`w-full border rounded p-2 ${formErrors.name ? 'border-red-500' : ''}`}
              placeholder="Enter fee structure name (e.g., Class 1A - Annual Fees)"
              value={formData.name}
              onChange={handleInputChange}
            />
            {formErrors.name && (
              <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>
            )}
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Fee Components*</label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
              {predefinedFeeNames.map((fee) => (
                <div
                  key={fee.id}
                  onClick={() => handleFeeNameSelect(fee)}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedFeeNames.includes(fee.id)
                      ? 'bg-red-50 border-red-200'
                      : 'bg-white hover:bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{fee.name}</span>
                    {selectedFeeNames.includes(fee.id) ? (
                      <Minus className="h-4 w-4 text-red-600" />
                    ) : (
                      <Plus className="h-4 w-4 text-gray-400" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              name="description"
              className="w-full border rounded p-2"
              placeholder="Optional description of the fee structure"
              rows="3"
              value={formData.description}
              onChange={handleInputChange}
            />
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Configure Selected Components*</label>
            {formData.components.length === 0 ? (
              <div className="text-center py-6 border-2 border-dashed rounded-lg">
                <p className="text-gray-500">Select fee components from above to configure amounts</p>
              </div>
            ) : (
              formData.components.map((component, index) => (
                <div key={component.id || index} className="border rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-800">{component.name}</h4>
                    <button
                      type="button"
                      onClick={() => handleRemoveComponent(index)}
                      className="text-red-600 hover:text-red-800 p-1"
                      title="Remove component"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-32">
                      <div className="relative">
                        <span className="absolute left-3 top-2">₹</span>
                        <input
                          type="number"
                          className={`w-full border rounded p-2 pl-8 ${formErrors.components?.[index]?.amount ? 'border-red-500' : ''}`}
                          placeholder="0.00"
                          value={component.amount}
                          onChange={(e) => handleComponentChange(index, 'amount', e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      {formErrors.components?.[index]?.amount && (
                        <p className="text-red-500 text-sm mt-1">{formErrors.components[index].amount}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mt-3">
                    <label className="inline-flex items-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-red-600 shadow-sm focus:border-red-300 focus:ring focus:ring-red-200 focus:ring-opacity-50"
                        checked={component.isTaxable}
                        onChange={(e) => handleComponentChange(index, 'isTaxable', e.target.checked)}
                      />
                      <span className="ml-2 text-sm text-gray-700">Taxable</span>
                    </label>
                    {component.isTaxable && (
                      <div className="w-24">
                        <div className="relative">
                          <input
                            type="number"
                            className={`w-full border rounded p-2 pr-8 ${formErrors.components?.[index]?.taxRate ? 'border-red-500' : ''}`}
                            placeholder="0"
                            value={component.taxRate}
                            onChange={(e) => handleComponentChange(index, 'taxRate', e.target.value)}
                            min="0"
                            max="100"
                          />
                          <span className="absolute right-3 top-2">%</span>
                        </div>
                        {formErrors.components?.[index]?.taxRate && (
                          <p className="text-red-500 text-sm mt-1">{formErrors.components[index].taxRate}</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="mb-6">
            <label className="inline-flex items-center">
              <input
                type="checkbox"
                name="isActive"
                className="rounded border-gray-300 text-red-600 shadow-sm focus:border-red-300 focus:ring focus:ring-red-200 focus:ring-opacity-50"
                checked={formData.isActive}
                onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              />
              <span className="ml-2 text-sm text-gray-700">Active</span>
            </label>
          </div>

          <div className="flex justify-between items-center">
            <div className="text-lg font-semibold">
              Total Amount: ₹{calculateTotal(formData.components).toLocaleString('en-IN')}
              {formData.components.some(c => c.isTaxable) && (
                <span className="text-sm text-gray-600 ml-2">(incl. taxes)</span>
              )}
            </div>
            <div className="flex gap-3">
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
              )}
              <button
                type="submit"
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:bg-red-400 flex items-center gap-2"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>

                    {editingId ? 'Updating...' : 'Saving...'}
                  </>
                ) : editingId ? (
                  'Update Fee Structure'
                ) : (
                  'Add Fee Structure'
                )}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* List Section */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Existing Fee Structures</h2>
          <div className="text-sm text-gray-500">
            Showing {feeStructures.length} structure{feeStructures.length !== 1 ? 's' : ''}
          </div>
        </div>

        {loading && feeStructures.length === 0 ? (
          <div className="text-center py-8">

          </div>
        ) : feeStructures.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No fee structures found matching your criteria
          </div>
        ) : (
          <div className="space-y-4">
            {feeStructures.map(structure => (
              <div key={structure._id} className="border rounded-lg overflow-hidden">
                <div
                  className={`flex justify-between items-center p-4 cursor-pointer hover:bg-gray-50 ${
                    expandedStructure === structure._id ? 'bg-gray-50 border-b' : ''
                  }`}
                  onClick={() => toggleExpandStructure(structure._id)}
                >
                  <div>
                    <h3 className="font-medium">
                      {structure.className || 'Unknown Class'} - {structure.name}
                    </h3>
                    <div className="flex flex-wrap gap-4 mt-1">
                      <span className="text-sm text-gray-600">
                        Year: <span className="font-medium">{structure.academicYear}</span>
                      </span>
                      {structure.sectionId && (
                        <span className="text-sm text-gray-600">
                          Section: <span className="font-medium">{structure.sectionId.name}</span>
                        </span>
                      )}
                      <span className="text-sm text-gray-600">
                        Frequency: <span className="font-medium capitalize">{structure.frequency}</span>
                      </span>
                      {structure.frequency !== 'one-time' && (
                        <span className="text-sm text-gray-600">
                          Due: <span className="font-medium">
                            {new Date(structure.dueDate).toLocaleDateString()}
                          </span>
                        </span>
                      )}
                      <span className="text-sm text-gray-600">
                        Total: <span className="font-medium">₹{(structure.totalAmount ?? 0).toLocaleString('en-IN')}</span>
                      </span>
                      <span className="text-sm">
                        Status: {structure.isActive ? (
                          <span className="text-green-600 font-medium">Active</span>
                        ) : (
                          <span className="text-red-600 font-medium">Inactive</span>
                        )}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDuplicate(structure);
                      }}
                      className="text-gray-600 hover:text-red-600 p-1"
                      title="Duplicate"
                    >
                      <Copy size={18} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(structure);
                      }}
                      className="text-gray-600 hover:text-red-600 p-1"
                      title="Edit"
                    >
                      <Edit size={18} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        confirmDelete(structure);
                      }}
                      className="text-gray-600 hover:text-red-600 p-1"
                      title="Delete"
                    >
                      <Trash2 size={18} />
                    </button>
                    {expandedStructure === structure._id ? (
                      <ChevronUp size={20} className="text-gray-500 ml-2" />
                    ) : (
                      <ChevronDown size={20} className="text-gray-500 ml-2" />
                    )}
                  </div>
                </div>
                {expandedStructure === structure._id && (
                  <div className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium mb-3 text-gray-700">Fee Components</h4>
                        <ul className="space-y-2">
                          {structure.components.map((comp, idx) => (
                            <li key={idx} className="flex justify-between py-1 border-b border-gray-100">
                              <div>
                                <span className="text-gray-700">{comp.name}</span>
                                {comp.isTaxable && (
                                  <span className="text-xs text-gray-500 ml-2">(+{comp.taxRate}% tax)</span>
                                )}
                              </div>
                              <span className="font-medium">₹{(comp.amount ?? 0).toLocaleString('en-IN')}</span>
                            </li>
                          ))}
                        </ul>
                        <div className="mt-3 pt-3 border-t flex justify-between font-medium">
                          <span>Total Amount:</span>
                          <span>₹{(structure.totalAmount ?? 0).toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-3 text-gray-700">Structure Details</h4>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Description:</span>
                            <span className="font-medium text-right">
                              {structure.description || 'None'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Frequency:</span>
                            <span className="font-medium capitalize">{structure.frequency}</span>
                          </div>
                          {structure.frequency !== 'one-time' && (
                            <div className="flex justify-between">
                              <span className="text-gray-600">Due Date:</span>
                              <span className="font-medium">
                                {new Date(structure.dueDate).toLocaleDateString()}
                              </span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span className="text-gray-600">Status:</span>
                            <span className={`font-medium ${
                              structure.isActive ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {structure.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Created:</span>
                            <span className="font-medium">
                              {new Date(structure.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Last Updated:</span>
                            <span className="font-medium">
                              {new Date(structure.updatedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDelete}
        title="Delete Fee Structure"
        message={`Are you sure you want to delete the fee structure "${structureToDelete?.name}" for ${structureToDelete?.className || 'Unknown Class'} - ${structureToDelete?.academicYear}?`}
        confirmText="Delete"
        cancelText="Cancel"
        danger
      />
    </div>
  );
};

export default FeeStructureManagement;
