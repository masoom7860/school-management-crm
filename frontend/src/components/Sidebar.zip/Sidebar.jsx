import { useState } from "react";
import {
  FaBars, 
  FaChevronDown,
} from "react-icons/fa";

const Sidebar = ({ menuItems, onMenuClick }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedSubmenus, setExpandedSubmenus] = useState({});

  const toggleSubmenu = (label) => {
    setExpandedSubmenus(prev => ({
      ...prev,
      [label]: !prev[label]
    }));
  };

  return (
    <div className={`flex min-h-screen ${isExpanded ? "w-64" : "w-20"} bg-black text-white transition-all duration-300`}>
      <div className="flex flex-col w-full">
        {/* Sidebar Header */}
        <div className="flex items-center justify-between px-4 py-4">
          <button className="bg-yellow-500 p-2 rounded-full text-black" onClick={() => setIsExpanded(!isExpanded)}>
            <FaBars />
          </button>
        </div>

        {/* Sidebar Menu Items */}
        <div className="flex flex-col space-y-2 mt-4">
          {menuItems.map((item, index) => (
            <div key={index}>
              <div
                className="flex items-center justify-between p-3 hover:bg-red-700 cursor-pointer"
                onClick={() => !item.subItems && onMenuClick(item.label)}
              >
                <div className="flex items-center space-x-4">
                  <span className="text-xl">{item.icon}</span>
                  {isExpanded && <span className="text-sm">{item.label}</span>}
                </div>
                {isExpanded && item.subItems && (
                  <button onClick={() => toggleSubmenu(item.label)}>
                    <FaChevronDown className={`transition-transform ${expandedSubmenus[item.label] ? "rotate-180" : ""}`} />
                  </button>
                )}
              </div>
              {isExpanded && item.subItems && expandedSubmenus[item.label] && (
                <div className="ml-6">
                  {item.subItems.map((subItem, subIndex) => (
                    <div
                      key={subIndex}
                      className="p-2 cursor-pointer hover:bg-red-600"
                      onClick={() => onMenuClick(subItem)}
                    >
                      {subItem}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
